BEGIN TRANSACTION;
DROP TABLE IF EXISTS "floating_tokens";
CREATE TABLE IF NOT EXISTS "floating_tokens" (
	"floating_token"	TEXT,
	"device_id"	TEXT NOT NULL,
	"license_key"	TEXT NOT NULL,
	PRIMARY KEY("license_key","device_id")
);
DROP TABLE IF EXISTS "devices";
CREATE TABLE IF NOT EXISTS "devices" (
	"device_id"	NUMERIC NOT NULL,
	"license_key"	TEXT NOT NULL,
	"floating_token"	TEXT NOT NULL DEFAULT "",
	"detail_info"	BLOB NOT NULL DEFAULT "",
	"dif"	BLOB NOT NULL DEFAULT "",
	"lif"	BLOB NOT NULL DEFAULT "",
	"rawdif"	BLOB NOT NULL DEFAULT "",
	"rawlif"	BLOB NOT NULL DEFAULT "",
	PRIMARY KEY("device_id","license_key")
);
DROP TABLE IF EXISTS "templates";
CREATE TABLE IF NOT EXISTS "templates" (
	"name"	TEXT,
	"value"	BLOB NOT NULL,
	PRIMARY KEY("name")
);
DROP TABLE IF EXISTS "license_keys";
CREATE TABLE IF NOT EXISTS "license_keys" (
	"license_key"	TEXT NOT NULL,
	"attributes"	BLOB NOT NULL,
	"product"	BLOB NOT NULL,
	PRIMARY KEY("license_key")
);
INSERT INTO "templates" VALUES ('license_info','{
         "device_type":[
            "VQTS_CLD"
         ],
         "duration":{
            "year":10,
            "day":0,
            "month":0
         },
         "app_min_version":"c4.4.2",
         "activation_ip":"1.1.1.1",
         "seats_info":{
            "total_free_unsubscribed":0,
            "total_activated":0,
            "lif_download_path":"",
            "seat_list":{
               
            },
            "max_seats":1,
            "available_seats":1,
            "total_seats":1,
            "total_unsubscribed":0
         },
         "license_id":"",
         "type":"device",
         "status":"valid",
         "app_display_name":"",
         "license_name":"",
         "quota":{
            "max_user":0,
            "max_device":1
         },
         "hashed":true,
         "available_seats":1,
         "license_key":"",
         "app_internal_name":"",
         "transferable":true,
         "license_credit":[
            {
               "duration":{
                  "year":10,
                  "day":0,
                  "month":0
               },
               "license_credit_id":"123456789"
            }
         ]
      }
');
INSERT INTO "templates" VALUES ('product_list','{"message":"ok","data":[{"url":"https:\/\/api-software.qnap.com\/api\/qnap-products\/1983","id":1983,"title":"QuMagie for QuTScloud","short_desc":"<ul>\n<li>\u4f7f\u7528 AI \u56fe\u50cf\u8bc6\u522b\u548c\u5143\u6570\u636e\u5206\u6790\u8bc6\u522b\u7167\u7247\u4e2d\u7684\u4eba\u8138\u3001\u7269\u54c1\u3001\u4e3b\u9898\u3001\u5730\u70b9\u548c\u5173\u952e\u5b57\u3002<\/li>\n<li>\u6839\u636e\u4eba\u7269\u3001\u7269\u54c1\u3001\u4e3b\u9898\u3001\u5730\u70b9\u6216\u5173\u952e\u5b57\u81ea\u52a8\u7ec4\u7ec7\u7167\u7247\u3002<\/li>\n<li>\u521b\u5efa\u4e0d\u540c\u7c7b\u578b\u7684\u76f8\u518c\uff0c\u4f7f\u7ec4\u7ec7\u4e2a\u6027\u5316\u3002<\/li>\n<li>\u5c06\u7075\u6d3b\u7684\u641c\u7d22\u6761\u4ef6\u4e0e QuMagie \u5f3a\u5927\u7684\u641c\u7d22\u529f\u80fd\u76f8\u7ed3\u5408\u3002<\/li>\n<li>\u901a\u8fc7\u5171\u4eab\u94fe\u63a5\u8f7b\u677e\u5171\u4eab\u76f8\u518c\u6216\u7167\u7247\u3002<\/li>\n<li>\u5229\u7528\u76f4\u89c2\u7684\u7528\u6237\u754c\u9762\u63d0\u4f9b\u6d41\u7545\u4f53\u9a8c\u3002<\/li>\n<\/ul>","sku":"VSKU-LS-QUMAGIE-QTSCLD","date_created":"2019-12-20T09:58:29Z","date_updated":"2022-03-10T07:09:24Z","recommended_products":[],"attributes":[{"name":"Purchase before installed (true\/false)","value":"true","code":"purchase_before_installed"},{"name":"Video Title 1","value":"Explore the brand-new QuMagie","code":"video_title_1"},{"name":"Allow Gift Message","value":"No","code":"gift_message_available"},{"name":"Product Class","value":"QuMagie_for_QTScloud","code":"product_class"},{"name":"Video URL 1","value":"https:\/\/www.youtube.com\/watch?v=XZOQepLi5MQ","code":"video_url_1"},{"name":"App Display Name","value":"QuMagie","code":"app_display_name"},{"name":"Video Image URL 1","value":"https:\/\/img.youtube.com\/vi\/XZOQepLi5MQ\/0.jpg","code":"video_image_url_1"},{"name":"App Internal Name","value":"qumagie","code":"app_internal_name"},{"name":"Meta Description","value":"QuMagie \u662f\u4e00\u79cd AI \u8f85\u52a9\u7167\u7247\u7ba1\u7406\u5e94\u7528\u7a0b\u5e8f\uff0c\u53ef\u8bc6\u522b\u7167\u7247\u4e2d\u7684\u4eba\u7269\u3001\u7269\u54c1\u6216\u4e3b\u9898\u5e76\u81ea\u52a8\u8fdb\u884c\u7ec4\u7ec7\u3002","code":"meta_description"},{"name":"Product Page Type","value":"Default","code":"product_page_type"},{"name":"License Activation","value":"<div class=\"qSW-pd-desc\"  id=\"qSW-pd-detail-license\">\n    \n    <iframe class=\"resize_height iframe_license_activation\" id=\"iframe_license_activation\" src=\"https:\/\/docs.qnap.com\/operating-system\/qts\/4.5.x\/zh-cn\/GUID-C6DE86F5-38A3-496E-A872-F833E1E5280D.html\" frameborder=\"0\" allowfullscreen=\"\" width=\"100%\" height=\"100%\" scrolling=\"no\"><\/iframe>\n\n<\/div>","code":"license_activation_info"},{"name":"Product Image Size","value":"Default","code":"product_image_size"},{"name":"Immediate Activate (true\/false)","value":true,"code":"immediate_activate"},{"name":"Display Actual Price","value":"Use config","code":"msrp_display_actual_price_type"},{"name":"Upgradeable","value":false,"code":"upgradeable"},{"name":"Device Type","value":"vqts_cld","code":"device_type"},{"name":"Pre-Gen Key","value":false,"code":"pre_gen_key"},{"name":"Quota (Max_device)","value":"1","code":"quota_device"},{"name":"Support Organization (true \/ false)","value":false,"code":"support_org"},{"name":"Transferable","value":true,"code":"transferable"},{"name":"Perpetual License (true\/false)","value":"false","code":"is_perpetual"},{"name":"License type (device or user)","value":"device","code":"type"},{"name":"Support Subscription(1\/0)","value":true,"code":"is_subscription"},{"name":"UI type","value":"Drop-down List","code":"ui_type"},{"name":"Is Bundle","value":false,"code":"is_bundle"},{"name":"Image Label","value":"QuMagie for QuTScloud","code":"image_label"},{"name":"Extend Check Type","value":"product.product_type","code":"ext_check_type"},{"name":"Small Image Label","value":"QuMagie for QuTScloud","code":"small_image_label"},{"name":"Require External Service","value":false,"code":"external_service"},{"name":"Thumbnail Label","value":"QuMagie for QuTScloud","code":"thumbnail_label"},{"name":"Extendable","value":true,"code":"extendable"},{"name":"Is floating","value":true,"code":"is_floating"},{"name":"Allow grace period","value":true,"code":"is_grace"},{"name":"Grace period given (days)","value":"1","code":"grace_period_days"},{"name":"Self Check Quota","value":true,"code":"is_self_check"},{"name":"Show Unit Price SKU","value":"LS-QUMAGIE-QTSCLD-1Y-EI","code":"shown_unit_price_sku"},{"name":"Product Owner","value":"0","code":"amrolepermissions_owner"},{"name":"Purchase before installed (true\/false)","value":"false","code":"purchase_before_installed"},{"name":"Child Skus","code":"child_skus","value":["LS-QUMAGIE-QTSCLD-1M-EI","LS-QUMAGIE-QTSCLD-1Y-EI"]}],"categories":[],"product_class":"QuMagie_for_QTScloud","stockrecords":"","images":[{"id":13627,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/8\/0\/800x800_product09_qumagie.png","caption":"","display_order":0,"date_created":"2019-12-20T09:58:29Z","tag":"image","product":1983},{"id":13627,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/8\/0\/800x800_product09_qumagie.png","caption":"","display_order":0,"date_created":"2019-12-20T09:58:29Z","tag":"logo","product":1983},{"id":13627,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/8\/0\/800x800_product09_qumagie.png","caption":"","display_order":1,"date_created":"2019-12-20T09:58:29Z","tag":"small_image","product":1983},{"id":13627,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/8\/0\/800x800_product09_qumagie.png","caption":"","display_order":2,"date_created":"2019-12-20T09:58:29Z","tag":"thumbnail","product":1983},{"id":13627,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/8\/0\/800x800_product09_qumagie.png","caption":"","display_order":3,"date_created":"2019-12-20T09:58:29Z","tag":"swatch_image","product":1983},{"id":13628,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/p\/r\/product_logo09_qumagie_w256.png","caption":"","display_order":4,"date_created":"2019-12-20T09:58:29Z","tag":"product_logo","product":1983}],"price":{"currency":"USD","excel_tax":99.99,"incl_tax":99.99,"tax":0},"availability":"","agreement":"","is_onshop":true,"product_url":"https:\/\/software.qnap.com\/qumagie-for-qutscloud.html"},{"url":"https:\/\/api-software.qnap.com\/api\/qnap-products\/2006","id":2006,"title":"QuTScloud","short_desc":"uTScloud \u5c06 QNAP NAS \u7684 QTS \u667a\u80fd\u64cd\u4f5c\u7cfb\u7edf\u90e8\u7f72\u4e8e\u516c\u6709\u4e91\u4e0a\u3002\u5728\u53ef\u652f\u6301\u7684\u4e91\u7aef\u670d\u52a1\u4e2d\u5b89\u88c5 QuTScloud \u64cd\u4f5c\u7cfb\u7edf\uff0c\u5373\u53ef\u542f\u7528\u60a8\u7684\u4e91 NAS\uff0c\u89e3\u51b3\u76ee\u524d\u4f7f\u7528\u4e2d\u7684\u4e91\u7aef\u5e73\u53f0\u65e0\u6cd5\u63d0\u4f9b\u6863\u6848\u7ba1\u7406\u53ca\u5f39\u6027\u5171\u4eab\u7b49\u9700\u6c42\u3002\u900f\u8fc7 QuTScloud \u670d\u52a1\uff0c\u60a8\u4e0d\u9700\u8981\u81ea\u5df1\u5904\u7406\u4e91\u7aef\u73af\u5883\u590d\u6742\u7684\u8fdb\u9636\u7ef4\u62a4\uff0c\u4eab\u53d7\u8f7b\u76c8\u53c8\u7cbe\u7701\u7684 QTS \u4f53\u9a8c\u3002QuTScloud \u4ea6\u53ef\u5b89\u88c5\u4e8e Linux\u00ae KVM\u3001Microsoft\u00ae Hyper-V \u6216 VMware\u00ae vSphere \u865a\u62df\u670d\u52a1\u5668\uff0c\u63d0\u4f9b\u60a8\u5e7f\u6cdb\u7684\u90e8\u7f72\u5e73\u53f0\u9009\u62e9\u3002","sku":"VSKU-LS-VQTSCLOUD","date_created":"2020-01-22T03:59:24Z","date_updated":"2022-03-19T02:01:48Z","recommended_products":[],"attributes":[{"name":"Purchase before installed (true\/false)","value":"false","code":"purchase_before_installed"},{"name":"Allow Gift Message","value":"No","code":"gift_message_available"},{"name":"Product Class","value":"vQTS_Cloud","code":"product_class"},{"name":"App Display Name","value":"QuTScloud","code":"app_display_name"},{"name":"App Internal Name","value":"vqtscloud","code":"app_internal_name"},{"name":"Min Version of App","value":"c4.4.2","code":"app_min_version"},{"name":"Product Page Type","value":"Default","code":"product_page_type"},{"name":"License Activation","value":"<div class=\"qSW-pd-desc\"  id=\"qSW-pd-detail-license\">\n    \n    <iframe class=\"resize_height iframe_license_activation\" id=\"iframe_license_activation\" src=\"https:\/\/docs.qnap.com\/operating-system\/qts\/4.5.x\/zh-cn\/GUID-C6DE86F5-38A3-496E-A872-F833E1E5280D.html\" frameborder=\"0\" allowfullscreen=\"\" width=\"100%\" height=\"100%\" scrolling=\"no\"><\/iframe>\n\n<\/div>","code":"license_activation_info"},{"name":"Product Image Size","value":"Default","code":"product_image_size"},{"name":"Immediate Activate (true\/false)","value":true,"code":"immediate_activate"},{"name":"Display Actual Price","value":"Use config","code":"msrp_display_actual_price_type"},{"name":"Upgradeable","value":true,"code":"upgradeable"},{"name":"Device Type","value":"vqts_cld","code":"device_type"},{"name":"Support Organization (true \/ false)","value":false,"code":"support_org"},{"name":"Pre-Gen Key","value":false,"code":"pre_gen_key"},{"name":"Perpetual License (true\/false)","value":"false","code":"is_perpetual"},{"name":"Quota (Max_device)","value":"1","code":"quota_device"},{"name":"Support Subscription(1\/0)","value":true,"code":"is_subscription"},{"name":"Transferable","value":true,"code":"transferable"},{"name":"License type (device or user)","value":"device","code":"type"},{"name":"Image Label","value":"QuTScloud","code":"image_label"},{"name":"UI type","value":"Drop-down List","code":"ui_type"},{"name":"Small Image Label","value":"QuTScloud","code":"small_image_label"},{"name":"Is Bundle","value":false,"code":"is_bundle"},{"name":"Thumbnail Label","value":"QuTScloud","code":"thumbnail_label"},{"name":"Extend Check Type","value":"product.product_type","code":"ext_check_type"},{"name":"Require External Service","value":false,"code":"external_service"},{"name":"Extendable","value":true,"code":"extendable"},{"name":"Use Product Advanced Pricing","value":"Use config","code":"aw_sarp2_is_used_advanced_pricing"},{"name":"Is floating","value":true,"code":"is_floating"},{"name":"Self Check Quota","value":true,"code":"is_self_check"},{"name":"Grace period given (days)","value":"21","code":"grace_period_days"},{"name":"Expiry Warning Day","value":"-1","code":"expiry_warning_day"},{"name":"Show Unit Price SKU","value":"LS-VQTSCLOUD-1CR-1Y-EI","code":"shown_unit_price_sku"},{"name":"Product Owner","value":"0","code":"amrolepermissions_owner"},{"name":"Purchase before installed (true\/false)","value":"false","code":"purchase_before_installed"},{"name":"Child Skus","code":"child_skus","value":["LS-VQTSCLOUD-1CR-1Y-EI","LS-VQTSCLOUD-1CR-1M-EI","LS-VQTSCLOUD-2CR-1Y-EI","LS-VQTSCLOUD-2CR-1M-EI","LS-VQTSCLOUD-4CR-1Y-EI","LS-VQTSCLOUD-4CR-1M-EI","LS-VQTSCLOUD-6CR-1Y-EI","LS-VQTSCLOUD-6CR-1M-EI","LS-VQTSCLOUD-8CR-1Y-EI","LS-VQTSCLOUD-8CR-1M-EI","LS-VQTSCLOUD-12CR-1Y-EI","LS-VQTSCLOUD-12CR-1M-EI","LS-VQTSCLOUD-16CR-1Y-EI","LS-VQTSCLOUD-16CR-1M-EI","LS-VQTSCLOUD-24+CR-1Y-EI","LS-VQTSCLOUD-24+CR-1M-EI","LS-QUTSCLOUD-1CR-1Y-EI","LS-QUTSCLOUD-1CR-1M-EI","LS-QUTSCLOUD-2CR-1Y-EI","LS-QUTSCLOUD-2CR-1M-EI","LS-QUTSCLOUD-4CR-1Y-EI","LS-QUTSCLOUD-4CR-1M-EI","LS-QUTSCLOUD-6CR-1Y-EI","LS-QUTSCLOUD-6CR-1M-EI","LS-QUTSCLOUD-8CR-1Y-EI","LS-QUTSCLOUD-8CR-1M-EI","LS-QUTSCLOUD-12CR-1Y-EI","LS-QUTSCLOUD-12CR-1M-EI","LS-QUTSCLOUD-16CR-1Y-EI","LS-QUTSCLOUD-16CR-1M-EI","LS-QUTSCLOUD-24+CR-1Y-EI","LS-QUTSCLOUD-24+CR-1M-EI"]}],"categories":[],"product_class":"vQTS_Cloud","stockrecords":"","images":[{"id":13423,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/q\/u\/qutscloud_cover_w800.jpg","caption":"","display_order":0,"date_created":"2020-01-22T03:59:24Z","tag":"image","product":2006},{"id":13423,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/q\/u\/qutscloud_cover_w800.jpg","caption":"","display_order":0,"date_created":"2020-01-22T03:59:24Z","tag":"logo","product":2006},{"id":13423,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/q\/u\/qutscloud_cover_w800.jpg","caption":"","display_order":1,"date_created":"2020-01-22T03:59:24Z","tag":"small_image","product":2006},{"id":13423,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/q\/u\/qutscloud_cover_w800.jpg","caption":"","display_order":2,"date_created":"2020-01-22T03:59:24Z","tag":"thumbnail","product":2006},{"id":13423,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/q\/u\/qutscloud_cover_w800.jpg","caption":"","display_order":3,"date_created":"2020-01-22T03:59:24Z","tag":"swatch_image","product":2006},{"id":13643,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/p\/r\/product_logo07_qtscloud_w256.png","caption":"","display_order":4,"date_created":"2020-01-22T03:59:24Z","tag":"product_logo","product":2006}],"price":{"currency":"USD","excel_tax":89.99,"incl_tax":89.99,"tax":0},"availability":"","agreement":"https:\/\/www.qnap.com\/solution\/qutscloud\/en\/#popup-agreement","is_onshop":true,"product_url":"https:\/\/software.qnap.com\/qutscloud.html"},{"url":"https:\/\/api-software.qnap.com\/api\/qnap-products\/2024","id":2024,"title":"OCR Converter for QuTScloud","short_desc":"OCR Converter \u5c06\u57fa\u4e8e\u6587\u672c\u7684\u56fe\u50cf\u8f6c\u6362\u4e3a\u53ef\u7f16\u8f91\u6587\u6863\u3002","sku":"VSKU-LS-OCR-QTSCLD","date_created":"2020-02-11T05:45:49Z","date_updated":"2022-03-10T07:02:48Z","recommended_products":[],"attributes":[{"name":"Purchase before installed (true\/false)","value":"true","code":"purchase_before_installed"},{"name":"Video Title 1","value":"Use Text Editor to edit source code, digitize files with OCR Converter","code":"video_title_1"},{"name":"Allow Gift Message","value":"No","code":"gift_message_available"},{"name":"Product Class","value":"OCRConverter","code":"product_class"},{"name":"Video URL 1","value":"https:\/\/www.youtube.com\/watch?v=URTAGHARww8","code":"video_url_1"},{"name":"App Display Name","value":"OCR Converter","code":"app_display_name"},{"name":"Video Image URL 1","value":"https:\/\/img.youtube.com\/vi\/URTAGHARww8\/0.jpg","code":"video_image_url_1"},{"name":"App Internal Name","value":"OCR_Converter","code":"app_internal_name"},{"name":"Meta Description","value":"OCR Converter \u5c06\u57fa\u4e8e\u6587\u672c\u7684\u56fe\u50cf\u8f6c\u6362\u4e3a\u53ef\u7f16\u8f91\u6587\u6863\u3002\u60a8\u53ef\u4ee5\u6307\u5b9a\u8f93\u51fa\u8bed\u8a00\u548c\u6587\u4ef6\u683c\u5f0f\uff0c\u5e76\u521b\u5efa\u8f6c\u6362\u8ba1\u5212\u4ee5\u63d0\u9ad8\u6548\u7387\u3002","code":"meta_description"},{"name":"Min Version of App","value":"1.2.0","code":"app_min_version"},{"name":"Product Page Type","value":"Default","code":"product_page_type"},{"name":"Product Image Size","value":"Default","code":"product_image_size"},{"name":"Immediate Activate (true\/false)","value":true,"code":"immediate_activate"},{"name":"Display Actual Price","value":"Use config","code":"msrp_display_actual_price_type"},{"name":"Device Type","value":"vqts_cld","code":"device_type"},{"name":"Pre-Gen Key","value":false,"code":"pre_gen_key"},{"name":"Support Organization (true \/ false)","value":false,"code":"support_org"},{"name":"Quota (Max_device)","value":"1","code":"quota_device"},{"name":"Perpetual License (true\/false)","value":"false","code":"is_perpetual"},{"name":"Transferable","value":true,"code":"transferable"},{"name":"Support Subscription(1\/0)","value":true,"code":"is_subscription"},{"name":"License type (device or user)","value":"device","code":"type"},{"name":"UI type","value":"Drop-down List","code":"ui_type"},{"name":"Image Label","value":"OCR Converter for QuTScloud","code":"image_label"},{"name":"Is Bundle","value":false,"code":"is_bundle"},{"name":"Small Image Label","value":"OCR Converter for QuTScloud","code":"small_image_label"},{"name":"Extend Check Type","value":"product.product_type","code":"ext_check_type"},{"name":"Thumbnail Label","value":"OCR Converter for QuTScloud","code":"thumbnail_label"},{"name":"Require External Service","value":false,"code":"external_service"},{"name":"Extendable","value":true,"code":"extendable"},{"name":"Is floating","value":true,"code":"is_floating"},{"name":"Allow grace period","value":true,"code":"is_grace"},{"name":"Grace period given (days)","value":"1","code":"grace_period_days"},{"name":"Self Check Quota","value":true,"code":"is_self_check"},{"name":"Show Unit Price SKU","value":"LS-OCR-QTSCLD-1Y-EI","code":"shown_unit_price_sku"},{"name":"Product Owner","value":"0","code":"amrolepermissions_owner"},{"name":"Purchase before installed (true\/false)","value":"true","code":"purchase_before_installed"},{"name":"Child Skus","code":"child_skus","value":["LS-OCR-QTSCLD-1M-EI","LS-OCR-QTSCLD-1Y-EI"]}],"categories":[],"product_class":"OCRConverter","stockrecords":"","images":[{"id":13837,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/o\/c\/ocr_converter_for_qtscloud_cover_w800.jpg","caption":"","display_order":0,"date_created":"2020-02-11T05:45:49Z","tag":"image","product":2024},{"id":13837,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/o\/c\/ocr_converter_for_qtscloud_cover_w800.jpg","caption":"","display_order":0,"date_created":"2020-02-11T05:45:49Z","tag":"logo","product":2024},{"id":13837,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/o\/c\/ocr_converter_for_qtscloud_cover_w800.jpg","caption":"","display_order":1,"date_created":"2020-02-11T05:45:49Z","tag":"small_image","product":2024},{"id":13837,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/o\/c\/ocr_converter_for_qtscloud_cover_w800.jpg","caption":"","display_order":2,"date_created":"2020-02-11T05:45:49Z","tag":"thumbnail","product":2024},{"id":13837,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/o\/c\/ocr_converter_for_qtscloud_cover_w800.jpg","caption":"","display_order":3,"date_created":"2020-02-11T05:45:49Z","tag":"swatch_image","product":2024},{"id":13250,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/o\/c\/ocr_converter_512.png","caption":"","display_order":4,"date_created":"2020-02-11T05:45:49Z","tag":"product_logo","product":2024}],"price":{"currency":"USD","excel_tax":49.99,"incl_tax":49.99,"tax":0},"availability":"","agreement":"","is_onshop":true,"product_url":"https:\/\/software.qnap.com\/ocr-converter-for-qutscloud.html"},{"url":"https:\/\/api-software.qnap.com\/api\/qnap-products\/2027","id":2027,"title":"Qfiling for QuTScloud","short_desc":"Qfiling \u53ef\u4e3a\u60a8\u81ea\u52a8\u5b8c\u6210\u6587\u4ef6\u7ec4\u7ec7\u4efb\u52a1\u3002 \u60a8\u53ea\u9700\u5c06\u6587\u4ef6\u5206\u7c7b\u5e76\u5236\u5b9a\u8ba1\u5212\uff0c\u5176\u4f59\u64cd\u4f5c\u5747\u7531 Qfiling \u5b8c\u6210\u3002 \u7b80\u5355\u3001\u667a\u80fd\u3001\u9ad8\u6548!","sku":"VSKU-LS-QFILING-QTSCLD","date_created":"2020-02-11T05:46:40Z","date_updated":"2022-03-10T07:27:34Z","recommended_products":[],"attributes":[{"name":"Purchase before installed (true\/false)","value":"true","code":"purchase_before_installed"},{"name":"Video Title 1","value":"Simplified file organization with Qfiling","code":"video_title_1"},{"name":"Allow Gift Message","value":"No","code":"gift_message_available"},{"name":"Product Class","value":"Qfiling","code":"product_class"},{"name":"Video URL 1","value":"https:\/\/www.youtube.com\/watch?v=w-64XPxIS7g","code":"video_url_1"},{"name":"App Display Name","value":"Qfiling for QuTScloud Upgrade","code":"app_display_name"},{"name":"Video Image URL 1","value":"https:\/\/img.youtube.com\/vi\/w-64XPxIS7g\/0.jpg","code":"video_image_url_1"},{"name":"App Internal Name","value":"Qfiling for QuTScloud Upgrade","code":"app_internal_name"},{"name":"Video Title 2","value":"Qfiling 2.1 explained: Browse and share images via Image2PDF file editing modules","code":"video_title_2"},{"name":"Meta Description","value":"Qfiling \u53ef\u4e3a\u60a8\u81ea\u52a8\u5b8c\u6210\u6587\u4ef6\u7ec4\u7ec7\u4efb\u52a1\u3002 \u60a8\u53ea\u9700\u5c06\u6587\u4ef6\u5206\u7c7b\u5e76\u5236\u5b9a\u8ba1\u5212\uff0c\u5176\u4f59\u64cd\u4f5c\u5747\u7531 Qfiling \u5b8c\u6210\u3002 \u7b80\u5355\u3001\u667a\u80fd\u3001\u9ad8\u6548!","code":"meta_description"},{"name":"Min Version of App","value":"3.0.0","code":"app_min_version"},{"name":"Video URL 2","value":"https:\/\/www.youtube.com\/watch?v=WvsIkVeUHJM","code":"video_url_2"},{"name":"Product Page Type","value":"Default","code":"product_page_type"},{"name":"License Activation","value":"<div class=\"qSW-pd-desc\"  id=\"qSW-pd-detail-license\">\n    \n    <iframe class=\"resize_height iframe_license_activation\" id=\"iframe_license_activation\" src=\"https:\/\/docs.qnap.com\/operating-system\/qts\/4.5.x\/zh-cn\/GUID-C6DE86F5-38A3-496E-A872-F833E1E5280D.html\" frameborder=\"0\" allowfullscreen=\"\" width=\"100%\" height=\"100%\" scrolling=\"no\"><\/iframe>\n\n<\/div>","code":"license_activation_info"},{"name":"Video Image URL 2","value":"https:\/\/img.youtube.com\/vi\/WvsIkVeUHJM\/0.jpg","code":"video_image_url_2"},{"name":"Product Image Size","value":"Default","code":"product_image_size"},{"name":"Immediate Activate (true\/false)","value":true,"code":"immediate_activate"},{"name":"Display Actual Price","value":"Use config","code":"msrp_display_actual_price_type"},{"name":"Upgradeable","value":true,"code":"upgradeable"},{"name":"Device Type","value":"vqts_cld","code":"device_type"},{"name":"Pre-Gen Key","value":false,"code":"pre_gen_key"},{"name":"Support Organization (true \/ false)","value":false,"code":"support_org"},{"name":"Quota (Max_device)","value":"1","code":"quota_device"},{"name":"Perpetual License (true\/false)","value":"false","code":"is_perpetual"},{"name":"Transferable","value":true,"code":"transferable"},{"name":"Support Subscription(1\/0)","value":true,"code":"is_subscription"},{"name":"License type (device or user)","value":"device","code":"type"},{"name":"UI type","value":"Drop-down List","code":"ui_type"},{"name":"Image Label","value":"Qfiling for QuTScloud","code":"image_label"},{"name":"Is Bundle","value":false,"code":"is_bundle"},{"name":"Small Image Label","value":"Qfiling for QuTScloud","code":"small_image_label"},{"name":"Extend Check Type","value":"product.product_type","code":"ext_check_type"},{"name":"Thumbnail Label","value":"Qfiling for QuTScloud","code":"thumbnail_label"},{"name":"Require External Service","value":false,"code":"external_service"},{"name":"Extendable","value":true,"code":"extendable"},{"name":"Is floating","value":true,"code":"is_floating"},{"name":"Allow grace period","value":true,"code":"is_grace"},{"name":"Grace period given (days)","value":"1","code":"grace_period_days"},{"name":"Self Check Quota","value":true,"code":"is_self_check"},{"name":"Show Unit Price SKU","value":"LS-QFILING-QTSCLD-1Y-EI","code":"shown_unit_price_sku"},{"name":"Product Owner","value":"0","code":"amrolepermissions_owner"},{"name":"Purchase before installed (true\/false)","value":"true","code":"purchase_before_installed"},{"name":"Child Skus","code":"child_skus","value":["LS-QFILING-QTSCLD-1M-EI","LS-QFILING-QTSCLD-1Y-EI","LS-QFILING-QTSCLD-1Y-PREM-EI","LS-QFILING-QTSCLD-1M-PREM-EI","LS-QFILING-QTSCLD-1Y-PLUS-EI","LS-QFILING-QTSCLD-1M-PLUS-EI"]}],"categories":[],"product_class":"Qfiling","stockrecords":"","images":[{"id":13658,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/q\/f\/qfiling_for_qtscloud_cover_w800_01.jpg","caption":"","display_order":0,"date_created":"2020-02-11T05:46:40Z","tag":"image","product":2027},{"id":13658,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/q\/f\/qfiling_for_qtscloud_cover_w800_01.jpg","caption":"","display_order":0,"date_created":"2020-02-11T05:46:40Z","tag":"logo","product":2027},{"id":13658,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/q\/f\/qfiling_for_qtscloud_cover_w800_01.jpg","caption":"","display_order":1,"date_created":"2020-02-11T05:46:40Z","tag":"small_image","product":2027},{"id":13658,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/q\/f\/qfiling_for_qtscloud_cover_w800_01.jpg","caption":"","display_order":2,"date_created":"2020-02-11T05:46:40Z","tag":"thumbnail","product":2027},{"id":13658,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/q\/f\/qfiling_for_qtscloud_cover_w800_01.jpg","caption":"","display_order":3,"date_created":"2020-02-11T05:46:40Z","tag":"swatch_image","product":2027},{"id":13277,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/q\/f\/qfiling_icon_w256.png","caption":"","display_order":4,"date_created":"2020-02-11T05:46:40Z","tag":"product_logo","product":2027}],"price":{"currency":"USD","excel_tax":99.99,"incl_tax":99.99,"tax":0},"availability":"","agreement":"","is_onshop":true,"product_url":"https:\/\/software.qnap.com\/qfiling-for-qutscloud.html"},{"url":"https:\/\/api-software.qnap.com\/api\/qnap-products\/2030","id":2030,"title":"Qsirch for QuTScloud","short_desc":"Qsirch \u662f\u4e00\u6b3e\u5f3a\u5927\u7684\u5168\u6587\u641c\u7d22\u5f15\u64ce\uff0c\u53ef\u5e2e\u52a9\u60a8\u5728 QuTScloud \u4e2d\u641c\u7d22\u6570\u636e\u3002","sku":"VSKU-LS-QSIRCH-QTSCLD","date_created":"2020-02-11T05:47:14Z","date_updated":"2022-03-19T02:02:46Z","recommended_products":[],"attributes":[{"name":"Purchase before installed (true\/false)","value":"true","code":"purchase_before_installed"},{"name":"Video Title 1","value":"New features of Qsirch 4.0: Map Search, Mac Finder Integration and NAS Exploration","code":"video_title_1"},{"name":"Allow Gift Message","value":"No","code":"gift_message_available"},{"name":"Product Class","value":"Qsirch","code":"product_class"},{"name":"Video URL 1","value":"https:\/\/www.youtube.com\/watch?v=SorojsXHrOo","code":"video_url_1"},{"name":"Meta Title","value":"Qsirch for QuTScloud","code":"meta_title"},{"name":"App Display Name","value":"Qsirch","code":"app_display_name"},{"name":"Video Image URL 1","value":"https:\/\/img.youtube.com\/vi\/SorojsXHrOo\/0.jpg","code":"video_image_url_1"},{"name":"App Internal Name","value":"Qsirch","code":"app_internal_name"},{"name":"Video Title 2","value":"Get the most from Qsirch''s file indexing and search","code":"video_title_2"},{"name":"Meta Description","value":"Qsirch \u662f\u4e00\u6b3e\u5f3a\u5927\u7684\u5168\u6587\u641c\u7d22\u5f15\u64ce\uff0c\u53ef\u5e2e\u52a9\u60a8\u5728 QuTScloud \u4e2d\u641c\u7d22\u6570\u636e\u3002","code":"meta_description"},{"name":"Min Version of App","value":"4.1.0","code":"app_min_version"},{"name":"Video URL 2","value":"https:\/\/www.youtube.com\/watch?v=i_TxxngZyNk","code":"video_url_2"},{"name":"Product Page Type","value":"Default","code":"product_page_type"},{"name":"License Activation","value":"<div class=\"qSW-pd-desc\"  id=\"qSW-pd-detail-license\">\n    \n    <iframe class=\"resize_height iframe_license_activation\" id=\"iframe_license_activation\" src=\"https:\/\/docs.qnap.com\/operating-system\/qts\/4.5.x\/zh-cn\/GUID-C6DE86F5-38A3-496E-A872-F833E1E5280D.html\" frameborder=\"0\" allowfullscreen=\"\" width=\"100%\" height=\"100%\" scrolling=\"no\"><\/iframe>\n\n<\/div>","code":"license_activation_info"},{"name":"Variant Display Name","value":"Qsirch for QuTScloud","code":"variant_display_name"},{"name":"Video Image URL 2","value":"https:\/\/img.youtube.com\/vi\/i_TxxngZyNk\/0.jpg","code":"video_image_url_2"},{"name":"Product Image Size","value":"Default","code":"product_image_size"},{"name":"Immediate Activate (true\/false)","value":true,"code":"immediate_activate"},{"name":"Display Actual Price","value":"Use config","code":"msrp_display_actual_price_type"},{"name":"Upgradeable","value":false,"code":"upgradeable"},{"name":"Device Type","value":"vqts_cld","code":"device_type"},{"name":"Pre-Gen Key","value":false,"code":"pre_gen_key"},{"name":"Quota (Max_device)","value":"1","code":"quota_device"},{"name":"Support Organization (true \/ false)","value":true,"code":"support_org"},{"name":"Transferable","value":true,"code":"transferable"},{"name":"Perpetual License (true\/false)","value":"false","code":"is_perpetual"},{"name":"License type (device or user)","value":"device","code":"type"},{"name":"Support Subscription(1\/0)","value":true,"code":"is_subscription"},{"name":"UI type","value":"Drop-down List","code":"ui_type"},{"name":"Is Bundle","value":false,"code":"is_bundle"},{"name":"Image Label","value":"Qsirch for QuTScloud","code":"image_label"},{"name":"Extend Check Type","value":"product.product_type","code":"ext_check_type"},{"name":"Small Image Label","value":"Qsirch for QuTScloud","code":"small_image_label"},{"name":"Require External Service","value":false,"code":"external_service"},{"name":"Thumbnail Label","value":"Qsirch for QuTScloud","code":"thumbnail_label"},{"name":"Extendable","value":true,"code":"extendable"},{"name":"Is floating","value":true,"code":"is_floating"},{"name":"Allow grace period","value":true,"code":"is_grace"},{"name":"Use Product Advanced Pricing","value":"Use config","code":"aw_sarp2_is_used_advanced_pricing"},{"name":"Grace period given (days)","value":"1","code":"grace_period_days"},{"name":"Self Check Quota","value":true,"code":"is_self_check"},{"name":"Show Unit Price SKU","value":"LS-QSIRCH-QTSCLD-1Y-EI","code":"shown_unit_price_sku"},{"name":"Product Owner","value":"0","code":"amrolepermissions_owner"},{"name":"Purchase before installed (true\/false)","value":"true","code":"purchase_before_installed"},{"name":"Child Skus","code":"child_skus","value":["LS-QSIRCH-QTSCLD-1M-EI","LS-QSIRCH-QTSCLD-1Y-EI"]}],"categories":[],"product_class":"Qsirch","stockrecords":"","images":[{"id":13938,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/q\/s\/qsirch_for_qtscloud_cover_w800._1_1.jpg","caption":"","display_order":0,"date_created":"2020-02-11T05:47:14Z","tag":"image","product":2030},{"id":13938,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/q\/s\/qsirch_for_qtscloud_cover_w800._1_1.jpg","caption":"","display_order":0,"date_created":"2020-02-11T05:47:14Z","tag":"logo","product":2030},{"id":13938,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/q\/s\/qsirch_for_qtscloud_cover_w800._1_1.jpg","caption":"","display_order":1,"date_created":"2020-02-11T05:47:14Z","tag":"small_image","product":2030},{"id":13938,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/q\/s\/qsirch_for_qtscloud_cover_w800._1_1.jpg","caption":"","display_order":2,"date_created":"2020-02-11T05:47:14Z","tag":"thumbnail","product":2030},{"id":13938,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/q\/s\/qsirch_for_qtscloud_cover_w800._1_1.jpg","caption":"","display_order":3,"date_created":"2020-02-11T05:47:14Z","tag":"swatch_image","product":2030},{"id":13651,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/p\/r\/product_logo_13_qsirch_w256_1.png","caption":"","display_order":4,"date_created":"2020-02-11T05:47:14Z","tag":"product_logo","product":2030}],"price":{"currency":"USD","excel_tax":99.99,"incl_tax":99.99,"tax":0},"availability":"","agreement":"","is_onshop":true,"product_url":"https:\/\/software.qnap.com\/qsirch-for-qutscloud.html"},{"url":"https:\/\/api-software.qnap.com\/api\/qnap-products\/2053","id":2053,"title":"Boxafe for QuTScloud","short_desc":"\u4f7f\u4e91\u4e2d\u7684\u4f01\u4e1a\u6570\u636e\u5b89\u5168\u65e0\u865e\u3002Boxafe \u662f\u4e00\u6b3e\u529f\u80fd\u5168\u9762\u7684\u4f01\u4e1a\u5907\u4efd\u89e3\u51b3\u65b9\u6848\uff0c\u9002\u7528\u4e8e QNAP Cloud NAS \u4e2d\u7684 Google\u2122 G Suite \u548c Microsoft\u00ae Office 365\u00ae\u3002\u60a8\u80fd\u591f\u9ad8\u5ea6\u5b89\u5168\u3001\u53ef\u9760\u5730\u96c6\u4e2d\u5907\u4efd\u4f01\u4e1a\u6570\u636e\u3002","sku":"VSKU-LS-BOXAFE-QTSCLD","date_created":"2020-05-02T12:44:59Z","date_updated":"2022-03-10T06:54:21Z","recommended_products":[],"attributes":[{"name":"Video Title 1","value":"Boxafe: A business backup solution for Google\u2122 G Suite and Microsoft\u00ae Office 365\u00ae","code":"video_title_1"},{"name":"Allow Gift Message","value":"No","code":"gift_message_available"},{"name":"Product Class","value":"Boxafe_for_QuTScloud","code":"product_class"},{"name":"App Display Name","value":"Boxafe","code":"app_display_name"},{"name":"Video URL 1","value":"https:\/\/www.youtube.com\/watch?v=bWEq0rs-yZs","code":"video_url_1"},{"name":"App Internal Name","value":"boxafe","code":"app_internal_name"},{"name":"Video Image URL 1","value":"https:\/\/img.youtube.com\/vi\/bWEq0rs-yZs\/0.jpg","code":"video_image_url_1"},{"name":"Min Version of App","value":"1.0.0","code":"app_min_version"},{"name":"Video Title 2","value":" ","code":"video_title_2"},{"name":"Meta Description","value":"Boxafe \u662f\u4e00\u6b3e\u529f\u80fd\u5168\u9762\u7684\u4f01\u4e1a\u5907\u4efd\u89e3\u51b3\u65b9\u6848\uff0c\u9002\u7528\u4e8e QNAP Cloud NAS \u4e2d\u7684 Google\u2122 G Suite \u548c Microsoft\u00ae Office 365\u00ae\u3002","code":"meta_description"},{"name":"Variant Display Name","value":"Boxafe for QuTScloud","code":"variant_display_name"},{"name":"Product Page Type","value":"Default","code":"product_page_type"},{"name":"License Activation","value":"<div class=\"qSW-pd-desc\"  id=\"qSW-pd-detail-license\">\n    \n    <iframe class=\"resize_height iframe_license_activation\" id=\"iframe_license_activation\" src=\"https:\/\/docs.qnap.com\/operating-system\/qts\/4.5.x\/zh-cn\/GUID-C6DE86F5-38A3-496E-A872-F833E1E5280D.html\" frameborder=\"0\" allowfullscreen=\"\" width=\"100%\" height=\"100%\" scrolling=\"no\"><\/iframe>\n\n<\/div>","code":"license_activation_info"},{"name":"Product Image Size","value":"Default","code":"product_image_size"},{"name":"Immediate Activate (true\/false)","value":true,"code":"immediate_activate"},{"name":"Display Actual Price","value":"Use config","code":"msrp_display_actual_price_type"},{"name":"Upgradeable","value":false,"code":"upgradeable"},{"name":"Extendable","value":true,"code":"extendable"},{"name":"Device Type","value":"vqts_cld","code":"device_type"},{"name":"License type (device or user)","value":"device","code":"type"},{"name":"Pre-Gen Key","value":false,"code":"pre_gen_key"},{"name":"Support Organization (true \/ false)","value":false,"code":"support_org"},{"name":"Quota (Max_device)","value":"1","code":"quota_device"},{"name":"Perpetual License (true\/false)","value":"false","code":"is_perpetual"},{"name":"Transferable","value":true,"code":"transferable"},{"name":"Support Subscription(1\/0)","value":true,"code":"is_subscription"},{"name":"UI type","value":"Drop-down List","code":"ui_type"},{"name":"Is Bundle","value":false,"code":"is_bundle"},{"name":"Image Label","value":"Boxafe for QuTScloud","code":"image_label"},{"name":"Extend Check Type","value":"product.product_type","code":"ext_check_type"},{"name":"Small Image Label","value":"Boxafe for QuTScloud","code":"small_image_label"},{"name":"Require External Service","value":false,"code":"external_service"},{"name":"Thumbnail Label","value":"Boxafe for QuTScloud","code":"thumbnail_label"},{"name":"Is floating","value":true,"code":"is_floating"},{"name":"Allow grace period","value":true,"code":"is_grace"},{"name":"Grace period given (days)","value":"1","code":"grace_period_days"},{"name":"Self Check Quota","value":true,"code":"is_self_check"},{"name":"Show Unit Price SKU","value":"LS-BOXAFE-QTSCLD-1Y-EI","code":"shown_unit_price_sku"},{"name":"Product Owner","value":"0","code":"amrolepermissions_owner"},{"name":"Purchase before installed (true\/false)","value":"true","code":"purchase_before_installed"},{"name":"Child Skus","code":"child_skus","value":["LS-BOXAFE-QTSCLD-1M-EI","LS-BOXAFE-QTSCLD-1Y-EI"]}],"categories":[],"product_class":"Boxafe_for_QuTScloud","stockrecords":"","images":[{"id":13300,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/b\/o\/boxafe_for_qutscloud_cover_w800.jpg","caption":"","display_order":0,"date_created":"2020-05-02T12:44:59Z","tag":"image","product":2053},{"id":13300,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/b\/o\/boxafe_for_qutscloud_cover_w800.jpg","caption":"","display_order":0,"date_created":"2020-05-02T12:44:59Z","tag":"logo","product":2053},{"id":13300,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/b\/o\/boxafe_for_qutscloud_cover_w800.jpg","caption":"","display_order":1,"date_created":"2020-05-02T12:44:59Z","tag":"small_image","product":2053},{"id":13300,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/b\/o\/boxafe_for_qutscloud_cover_w800.jpg","caption":"","display_order":2,"date_created":"2020-05-02T12:44:59Z","tag":"thumbnail","product":2053},{"id":13300,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/b\/o\/boxafe_for_qutscloud_cover_w800.jpg","caption":"","display_order":3,"date_created":"2020-05-02T12:44:59Z","tag":"swatch_image","product":2053},{"id":13646,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/p\/r\/product_logo_boxafe_for_qutsclound_01_w256.png","caption":"","display_order":4,"date_created":"2020-05-02T12:44:59Z","tag":"product_logo","product":2053}],"price":{"currency":"USD","excel_tax":99.99,"incl_tax":99.99,"tax":0},"availability":"","agreement":"","is_onshop":true,"product_url":"https:\/\/software.qnap.com\/boxafe-for-qutscloud.html"},{"url":"https:\/\/api-software.qnap.com\/api\/qnap-products\/2075","id":2075,"title":"QmailAgent for QuTScloud","short_desc":"<p>QmailAgent \u662f\u5b89\u5168\u7684\u7535\u5b50\u90ae\u4ef6\u89e3\u51b3\u65b9\u6848\uff0c\u652f\u6301\u591a\u4e2a\u4e3b\u8981\u7684\u7535\u5b50\u90ae\u4ef6\u670d\u52a1\u548c\u4f7f\u7528 IMAP \u7684\u7535\u5b50\u90ae\u4ef6\u670d\u52a1\uff0c\u4f7f\u60a8\u80fd\u591f\u8f7b\u677e\u7ba1\u7406\u591a\u4e2a\u7535\u5b50\u90ae\u4ef6\u5e10\u6237\u3002\u501f\u52a9 QmailAgent \u53ef\u5b9e\u73b0\u4ee5\u4e0b\u529f\u80fd\uff1a<\/p>\n<ul>\n<li>\u5b89\u5168\u5730\u96c6\u4e2d\u7ba1\u7406\u591a\u4e2a\u7535\u5b50\u90ae\u4ef6\u5e10\u6237\uff0c\u901a\u8fc7\u60a8\u7684 NAS IP \u53d1\u9001\u548c\u63a5\u6536\u7535\u5b50\u90ae\u4ef6\u3002<\/li>\n<li>\u5bf9\u7535\u5b50\u90ae\u4ef6\u5185\u5bb9\u548c\u9644\u4ef6\u8fdb\u884c\u5168\u6587\u641c\u7d22\u3002<\/li>\n<li>\u5c06\u6240\u6709\u7684\u7535\u5b50\u90ae\u4ef6\u4ece\u90ae\u4ef6\u670d\u52a1\u5668\u5907\u4efd\u5230\u60a8\u7684\u79c1\u4eba NAS \u4e0a\u3002<\/li>\n<li>\u5c06\u6240\u6709\u90ae\u7bb1\u4ece NAS \u8fdb\u884c\u6b21\u8981\u5907\u4efd\u5e76\u5f52\u6863\u5230\u8fdc\u7a0b\u5b58\u50a8\uff0c\u4fbf\u4e8e\u707e\u96be\u6062\u590d\u3002<\/li>\n<li>\u5c06\u7535\u5b50\u90ae\u4ef6\u4ece\u90ae\u7bb1\u8fc1\u79fb\u5230\u90ae\u7bb1\u3002<\/li>\n<\/ul>","sku":"VSKU-LS-QMAIL-QTSCLD","date_created":"2020-05-25T06:13:15Z","date_updated":"2022-03-10T07:15:13Z","recommended_products":[],"attributes":[{"name":"Purchase before installed (true\/false)","value":"true","code":"purchase_before_installed"},{"name":"Video Title 1","value":"QNAP QmailAgent - A mailroom center for your private cloud","code":"video_title_1"},{"name":"Allow Gift Message","value":"No","code":"gift_message_available"},{"name":"Product Class","value":"QmailAgent_for_QuTScloud","code":"product_class"},{"name":"Video URL 1","value":"https:\/\/www.youtube.com\/watch?v=oAVSHGPIIYU","code":"video_url_1"},{"name":"App Display Name","value":"QmailAgent","code":"app_display_name"},{"name":"Video Image URL 1","value":"https:\/\/img.youtube.com\/vi\/oAVSHGPIIYU\/0.jpg","code":"video_image_url_1"},{"name":"App Internal Name","value":"qmail","code":"app_internal_name"},{"name":"Video Title 2","value":" ","code":"video_title_2"},{"name":"Meta Description","value":"\u501f\u52a9 QNAP QmailAgent\uff0c\u53ef\u4ee5\u5b89\u5168\u5730\u96c6\u4e2d\u7ba1\u7406\uff0c\u5e76\u8f7b\u677e\u5907\u4efd\u591a\u4e2a\u7535\u5b50\u90ae\u4ef6\u5e10\u6237\u3002","code":"meta_description"},{"name":"Min Version of App","value":"2.3.0","code":"app_min_version"},{"name":"Product Page Type","value":"Default","code":"product_page_type"},{"name":"License Activation","value":"<div class=\"qSW-pd-desc\"  id=\"qSW-pd-detail-license\">\n    \n    <iframe class=\"resize_height iframe_license_activation\" id=\"iframe_license_activation\" src=\"https:\/\/docs.qnap.com\/operating-system\/qts\/4.5.x\/zh-cn\/GUID-C6DE86F5-38A3-496E-A872-F833E1E5280D.html\" frameborder=\"0\" allowfullscreen=\"\" width=\"100%\" height=\"100%\" scrolling=\"no\"><\/iframe>\n\n<\/div>","code":"license_activation_info"},{"name":"Variant Display Name","value":"QmailAgent for QuTScloud","code":"variant_display_name"},{"name":"Product Image Size","value":"Default","code":"product_image_size"},{"name":"Immediate Activate (true\/false)","value":true,"code":"immediate_activate"},{"name":"Variant Feature","value":"premium","code":"variant_feature"},{"name":"Display Actual Price","value":"Use config","code":"msrp_display_actual_price_type"},{"name":"Upgradeable","value":false,"code":"upgradeable"},{"name":"Device Type","value":"vqts_cld","code":"device_type"},{"name":"Extendable","value":true,"code":"extendable"},{"name":"Support Organization (true \/ false)","value":false,"code":"support_org"},{"name":"License type (device or user)","value":"device","code":"type"},{"name":"Perpetual License (true\/false)","value":"false","code":"is_perpetual"},{"name":"Pre-Gen Key","value":false,"code":"pre_gen_key"},{"name":"Support Subscription(1\/0)","value":true,"code":"is_subscription"},{"name":"Quota (Max_device)","value":"1","code":"quota_device"},{"name":"Transferable","value":true,"code":"transferable"},{"name":"Image Label","value":"QmailAgent for QuTScloud","code":"image_label"},{"name":"UI type","value":"Drop-down List","code":"ui_type"},{"name":"Small Image Label","value":"QmailAgent for QuTScloud","code":"small_image_label"},{"name":"Is Bundle","value":false,"code":"is_bundle"},{"name":"Thumbnail Label","value":"QmailAgent for QuTScloud","code":"thumbnail_label"},{"name":"Extend Check Type","value":"product.product_type","code":"ext_check_type"},{"name":"Require External Service","value":false,"code":"external_service"},{"name":"Is floating","value":true,"code":"is_floating"},{"name":"Allow grace period","value":true,"code":"is_grace"},{"name":"Grace period given (days)","value":"1","code":"grace_period_days"},{"name":"Self Check Quota","value":true,"code":"is_self_check"},{"name":"Show Unit Price SKU","value":"LS-QMAIL-QTSCLD-1Y-EI","code":"shown_unit_price_sku"},{"name":"Product Owner","value":"0","code":"amrolepermissions_owner"},{"name":"Purchase before installed (true\/false)","value":"true","code":"purchase_before_installed"},{"name":"Child Skus","code":"child_skus","value":["LS-QMAIL-QTSCLD-1M-EI","LS-QMAIL-QTSCLD-1Y-EI"]}],"categories":[],"product_class":"QmailAgent_for_QuTScloud","stockrecords":"","images":[{"id":13329,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/q\/m\/qmailagent_for_qutscloud_cover_w800.jpg","caption":"","display_order":0,"date_created":"2020-05-25T06:13:15Z","tag":"image","product":2075},{"id":13329,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/q\/m\/qmailagent_for_qutscloud_cover_w800.jpg","caption":"","display_order":0,"date_created":"2020-05-25T06:13:15Z","tag":"logo","product":2075},{"id":13329,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/q\/m\/qmailagent_for_qutscloud_cover_w800.jpg","caption":"","display_order":1,"date_created":"2020-05-25T06:13:15Z","tag":"small_image","product":2075},{"id":13329,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/q\/m\/qmailagent_for_qutscloud_cover_w800.jpg","caption":"","display_order":2,"date_created":"2020-05-25T06:13:15Z","tag":"thumbnail","product":2075},{"id":13329,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/q\/m\/qmailagent_for_qutscloud_cover_w800.jpg","caption":"","display_order":3,"date_created":"2020-05-25T06:13:15Z","tag":"swatch_image","product":2075},{"id":13645,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/p\/r\/product_logo_1_qmailagent_for_qtscloud_w256.png","caption":"","display_order":4,"date_created":"2020-05-25T06:13:15Z","tag":"product_logo","product":2075}],"price":{"currency":"USD","excel_tax":99.99,"incl_tax":99.99,"tax":0},"availability":"","agreement":"","is_onshop":true,"product_url":"https:\/\/software.qnap.com\/qmailagent-for-qutscloud.html"},{"url":"https:\/\/api-software.qnap.com\/api\/qnap-products\/2135","id":2135,"title":"HybridMount for QuTScloud","short_desc":"\u8ba9\u60a8\u5728\u8bbf\u95ee\u6d77\u91cf\u4e91\u6570\u636e\u65f6\u83b7\u5f97\u66f4\u4f73\u7684\u4f53\u9a8c\u548c\u66f4\u9ad8\u7684\u6548\u7387\uff0c\u6570\u636e\u5b58\u50a8\u5728\u4e91\u7aef\uff0c\u4e50\u4eab QTS \u4e2d\u7684\u5404\u79cd\u5e94\u7528\u7a0b\u5e8f\u3002","sku":"VSKU-LS-HM-QTSCLD","date_created":"2020-06-29T03:40:31Z","date_updated":"2022-03-10T06:48:40Z","recommended_products":[],"attributes":[{"name":"Purchase before installed (true\/false)","value":"false","code":"purchase_before_installed"},{"name":"Video Title 1","value":"Multimedia Console x HybridMount: Manage Multimedia Contents in Hybrid Cloud","code":"video_title_1"},{"name":"Allow Gift Message","value":"No","code":"gift_message_available"},{"name":"Product Class","value":"HybridMount_for_QTScloud","code":"product_class"},{"name":"Video URL 1","value":"https:\/\/www.youtube.com\/watch?v=vjscizJSItY","code":"video_url_1"},{"name":"Meta Title","value":"HybridMount for QuTScloud","code":"meta_title"},{"name":"App Display Name","value":"HybridMount","code":"app_display_name"},{"name":"Video Image URL 1","value":"https:\/\/img.youtube.com\/vi\/vjscizJSItY\/0.jpg","code":"video_image_url_1"},{"name":"App Internal Name","value":"CacheMount","code":"app_internal_name"},{"name":"Video Title 2","value":"HybridMount \/ VJBOD Cloud \u96f2\u7db2\u95dc\u8207\u96f2\u5275\u65b0\uff5cQNAP 20th Tech day","code":"video_title_2"},{"name":"Min Version of App","value":"1.0.1862","code":"app_min_version"},{"name":"Video URL 2","value":"https:\/\/www.youtube.com\/watch?v=feMm3mi0wmQ","code":"video_url_2"},{"name":"Product Page Type","value":"Default","code":"product_page_type"},{"name":"License Activation","value":"<div class=\"qSW-pd-desc\"  id=\"qSW-pd-detail-license\">\n    \n    <iframe class=\"resize_height iframe_license_activation\" id=\"iframe_license_activation\" src=\"https:\/\/docs.qnap.com\/operating-system\/qts\/4.5.x\/zh-cn\/GUID-C6DE86F5-38A3-496E-A872-F833E1E5280D.html\" frameborder=\"0\" allowfullscreen=\"\" width=\"100%\" height=\"100%\" scrolling=\"no\"><\/iframe>\n\n<\/div>","code":"license_activation_info"},{"name":"Video Image URL 2","value":"https:\/\/img.youtube.com\/vi\/feMm3mi0wmQ\/0.jpg","code":"video_image_url_2"},{"name":"Product Image Size","value":"Default","code":"product_image_size"},{"name":"Immediate Activate (true\/false)","value":true,"code":"immediate_activate"},{"name":"Video Title 3","value":"HybridMount: a file-based cloud storage gateway allows public cloud access like on a local NAS","code":"video_title_3"},{"name":"Display Actual Price","value":"Use config","code":"msrp_display_actual_price_type"},{"name":"Video URL 3","value":"https:\/\/www.youtube.com\/watch?v=cInAKsdIAlM","code":"video_url_3"},{"name":"Video Image URL 3","value":"https:\/\/img.youtube.com\/vi\/cInAKsdIAlM\/0.jpg","code":"video_image_url_3"},{"name":"Device Type","value":"vqts_cld","code":"device_type"},{"name":"Duration Year","value":"1","code":"duration_year"},{"name":"Connection","value":"1","code":"connection"},{"name":"Support Organization (true \/ false)","value":true,"code":"support_org"},{"name":"Pre-Gen Key","value":true,"code":"pre_gen_key"},{"name":"Perpetual License (true\/false)","value":"false","code":"is_perpetual"},{"name":"Quota (Max_device)","value":"1","code":"quota_device"},{"name":"Support Subscription(1\/0)","value":true,"code":"is_subscription"},{"name":"Transferable","value":true,"code":"transferable"},{"name":"License type (device or user)","value":"device","code":"type"},{"name":"Image Label","value":"HybridMount for QuTScloud","code":"image_label"},{"name":"UI type","value":"Drop-down List","code":"ui_type"},{"name":"Small Image Label","value":"HybridMount for QuTScloud","code":"small_image_label"},{"name":"Is Bundle","value":false,"code":"is_bundle"},{"name":"Thumbnail Label","value":"HybridMount for QuTScloud","code":"thumbnail_label"},{"name":"Extend Check Type","value":"product.product_type","code":"ext_check_type"},{"name":"Require External Service","value":false,"code":"external_service"},{"name":"Extendable","value":true,"code":"extendable"},{"name":"Is floating","value":true,"code":"is_floating"},{"name":"Allow grace period","value":true,"code":"is_grace"},{"name":"Grace period given (days)","value":"5","code":"grace_period_days"},{"name":"Show Unit Price SKU","value":"LS-HM-1CON-QTSCLD-1Y-EI","code":"shown_unit_price_sku"},{"name":"Product Owner","value":"0","code":"amrolepermissions_owner"},{"name":"Purchase before installed (true\/false)","value":"false","code":"purchase_before_installed"},{"name":"Child Skus","code":"child_skus","value":["VSKU-LS-HM-QTSCLD","LS-HM-1CON-QTSCLD-1Y-EI","LS-HM-4CON-QTSCLD-1Y-EI","LS-HM-8CON-QTSCLD-1Y-EI","LS-HM-1CON-QTSCLD-1M-EI","LS-HM-4CON-QTSCLD-1M-EI","LS-HM-8CON-QTSCLD-1M-EI"]}],"categories":[],"product_class":"HybridMount_for_QTScloud","stockrecords":"","images":[{"id":13621,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/8\/0\/800x800_product01_hybridmount_1.png","caption":"","display_order":0,"date_created":"2020-06-29T03:40:31Z","tag":"image","product":2135},{"id":13621,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/8\/0\/800x800_product01_hybridmount_1.png","caption":"","display_order":0,"date_created":"2020-06-29T03:40:31Z","tag":"logo","product":2135},{"id":13621,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/8\/0\/800x800_product01_hybridmount_1.png","caption":"","display_order":1,"date_created":"2020-06-29T03:40:31Z","tag":"small_image","product":2135},{"id":13621,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/8\/0\/800x800_product01_hybridmount_1.png","caption":"","display_order":2,"date_created":"2020-06-29T03:40:31Z","tag":"thumbnail","product":2135},{"id":13621,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/8\/0\/800x800_product01_hybridmount_1.png","caption":"","display_order":3,"date_created":"2020-06-29T03:40:31Z","tag":"swatch_image","product":2135},{"id":13622,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/p\/r\/product_logo01_hybridmount_w256.png","caption":"","display_order":4,"date_created":"2020-06-29T03:40:31Z","tag":"product_logo","product":2135}],"price":{"currency":"USD","excel_tax":39.99,"incl_tax":39.99,"tax":0},"availability":"","agreement":"","is_onshop":true,"product_url":"https:\/\/software.qnap.com\/hybridmount-for-qutscloud.html"},{"url":"https:\/\/api-software.qnap.com\/api\/qnap-products\/2142","id":2142,"title":"VJBOD Cloud for QuTScloud","short_desc":"VJBOD Cloud \u662f\u4e00\u4e2a\u533a\u5757\u5b58\u50a8\u7f51\u5173\u89e3\u51b3\u65b9\u6848\uff0c\u53ef\u4f9b\u60a8\u4f7f\u7528\u4e91\u670d\u52a1\uff08\u4f8b\u5982 Amazon\u3001Azure \u548c Google Cloud\uff09\u63d0\u4f9b\u7684\u4e91\u7a7a\u95f4\u5728\u672c\u5730 NAS \u4e0a\u65e0\u7f1d\u5907\u4efd\u6570\u636e\u3002","sku":"VSKU-LS-VJBODCLOUD-QTSCLD","date_created":"2020-06-29T03:52:04Z","date_updated":"2022-03-19T02:08:34Z","recommended_products":[],"attributes":[{"name":"Purchase before installed (true\/false)","value":"false","code":"purchase_before_installed"},{"name":"Video Title 1","value":"QNAP VJBOD (Virtual JBOD) for maximized sharing benefits","code":"video_title_1"},{"name":"Allow Gift Message","value":"No","code":"gift_message_available"},{"name":"Product Class","value":"VJBOD","code":"product_class"},{"name":"Video URL 1","value":"https:\/\/www.youtube.com\/watch?v=iEUJv-ke4dE","code":"video_url_1"},{"name":"App Display Name","value":"VJBOD Cloud","code":"app_display_name"},{"name":"Video Image URL 1","value":"https:\/\/img.youtube.com\/vi\/iEUJv-ke4dE\/0.jpg","code":"video_image_url_1"},{"name":"App Internal Name","value":"VJBOD_Cloud_Plug-in","code":"app_internal_name"},{"name":"Video Title 2","value":"Introducing VJBOD Cloud: The block-based cloud storage gateway","code":"video_title_2"},{"name":"Meta Description","value":"VJBOD Cloud is a block-based storage gateway solution that allows you to backup the storage space on your local NAS using cloud space from cloud services providers such as Amazon, Azure, and Google Cloud.","code":"meta_description"},{"name":"Min Version of App","value":"1.0.0","code":"app_min_version"},{"name":"Video URL 2","value":"https:\/\/www.youtube.com\/watch?v=1Zsr7eW2xaE","code":"video_url_2"},{"name":"Product Page Type","value":"Default","code":"product_page_type"},{"name":"License Activation","value":"<div class=\"qSW-pd-desc\"  id=\"qSW-pd-detail-license\">\n    \n    <iframe class=\"resize_height iframe_license_activation\" id=\"iframe_license_activation\" src=\"https:\/\/docs.qnap.com\/operating-system\/qts\/4.5.x\/zh-cn\/GUID-C6DE86F5-38A3-496E-A872-F833E1E5280D.html\" frameborder=\"0\" allowfullscreen=\"\" width=\"100%\" height=\"100%\" scrolling=\"no\"><\/iframe>\n\n<\/div>","code":"license_activation_info"},{"name":"Video Image URL 2","value":"https:\/\/img.youtube.com\/vi\/1Zsr7eW2xaE\/0.jpg","code":"video_image_url_2"},{"name":"Product Image Size","value":"Default","code":"product_image_size"},{"name":"Immediate Activate (true\/false)","value":true,"code":"immediate_activate"},{"name":"Video Title 3","value":"HybridMount \/ VJBOD Cloud \u96f2\u7db2\u95dc\u8207\u96f2\u5275\u65b0\uff5cQNAP 20th Tech day","code":"video_title_3"},{"name":"Display Actual Price","value":"Use config","code":"msrp_display_actual_price_type"},{"name":"Upgradeable","value":false,"code":"upgradeable"},{"name":"Video URL 3","value":"https:\/\/www.youtube.com\/watch?v=feMm3mi0wmQ","code":"video_url_3"},{"name":"Video Image URL 3","value":"https:\/\/img.youtube.com\/vi\/feMm3mi0wmQ\/0.jpg","code":"video_image_url_3"},{"name":"Device Type","value":"vqts_cld","code":"device_type"},{"name":"Extendable","value":true,"code":"extendable"},{"name":"License type (device or user)","value":"device","code":"type"},{"name":"Support Organization (true \/ false)","value":false,"code":"support_org"},{"name":"Pre-Gen Key","value":false,"code":"pre_gen_key"},{"name":"Perpetual License (true\/false)","value":"false","code":"is_perpetual"},{"name":"Quota (Max_device)","value":"1","code":"quota_device"},{"name":"Support Subscription(1\/0)","value":true,"code":"is_subscription"},{"name":"Transferable","value":true,"code":"transferable"},{"name":"Image Label","value":"VJBOD Cloud for QuTScloud","code":"image_label"},{"name":"UI type","value":"Drop-down List","code":"ui_type"},{"name":"Small Image Label","value":"VJBOD Cloud for QuTScloud","code":"small_image_label"},{"name":"Is Bundle","value":false,"code":"is_bundle"},{"name":"Thumbnail Label","value":"VJBOD Cloud for QuTScloud","code":"thumbnail_label"},{"name":"Extend Check Type","value":"product.product_type","code":"ext_check_type"},{"name":"Require External Service","value":false,"code":"external_service"},{"name":"Is floating","value":true,"code":"is_floating"},{"name":"Use Product Advanced Pricing","value":"Use config","code":"aw_sarp2_is_used_advanced_pricing"},{"name":"Allow grace period","value":true,"code":"is_grace"},{"name":"Grace period given (days)","value":"1","code":"grace_period_days"},{"name":"Self Check Quota","value":true,"code":"is_self_check"},{"name":"Show Unit Price SKU","value":"LS-VJBODCLOUD-QTSCLD-4C-1Y-EI","code":"shown_unit_price_sku"},{"name":"Product Owner","value":"0","code":"amrolepermissions_owner"},{"name":"Purchase before installed (true\/false)","value":"false","code":"purchase_before_installed"},{"name":"Child Skus","code":"child_skus","value":["LS-VJBODCLOUD-QTSCLD-1C-1Y-EI","LS-VJBODCLOUD-QTSCLD-4C-1Y-EI","LS-VJBODCLOUD-QTSCLD-8C-1Y-EI","LS-VJBODCLOUD-QTSCLD-1C-1M-EI","LS-VJBODCLOUD-QTSCLD-4C-1M-EI","LS-VJBODCLOUD-QTSCLD-8C-1M-EI"]}],"categories":[],"product_class":"VJBOD","stockrecords":"","images":[{"id":13611,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/8\/0\/800x800_product02_vjbod_cloud_1.png","caption":"","display_order":0,"date_created":"2020-06-29T03:52:04Z","tag":"image","product":2142},{"id":13611,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/8\/0\/800x800_product02_vjbod_cloud_1.png","caption":"","display_order":0,"date_created":"2020-06-29T03:52:04Z","tag":"logo","product":2142},{"id":13611,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/8\/0\/800x800_product02_vjbod_cloud_1.png","caption":"","display_order":1,"date_created":"2020-06-29T03:52:04Z","tag":"small_image","product":2142},{"id":13611,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/8\/0\/800x800_product02_vjbod_cloud_1.png","caption":"","display_order":2,"date_created":"2020-06-29T03:52:04Z","tag":"thumbnail","product":2142},{"id":13611,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/8\/0\/800x800_product02_vjbod_cloud_1.png","caption":"","display_order":3,"date_created":"2020-06-29T03:52:04Z","tag":"swatch_image","product":2142},{"id":13612,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/p\/r\/product_logo02_vjbodcloud_w256.png","caption":"","display_order":4,"date_created":"2020-06-29T03:52:04Z","tag":"product_logo","product":2142}],"price":{"currency":"USD","excel_tax":69.99,"incl_tax":69.99,"tax":0},"availability":"","agreement":"","is_onshop":true,"product_url":"https:\/\/software.qnap.com\/vjbod-cloud-for-qutscloud.html"},{"url":"https:\/\/api-software.qnap.com\/api\/qnap-products\/2149","id":2149,"title":"McAfee Antivirus for QuTScloud","short_desc":"<p>\u4f7f\u7528 McAfee \u6740\u6bd2\u5f15\u64ce\u624b\u52a8\u6216\u6309\u8ba1\u5212\u626b\u63cf NAS \u4e0a\u7684\u6076\u610f\u8f6f\u4ef6\u3002<\/p>\n<p style=\"padding: 5px 10px;background: #ffefd6;color: #ce7c5d;\">McAfee antivirus license can be purchased for a yearly or bi-yearly basis only. <br\/><br\/>It does not support a monthly license as per the current McAfee policy now.\nIf you have purchased the monthly license for QuTScloud, please note that you can not use McAfee once the QuTScloud license expires until you re-subscription and re-activated the QuTScloud.<\/p>","sku":"VSKU-LS-MCAFEE-QTSCLD","date_created":"2020-06-29T04:11:35Z","date_updated":"2021-10-27T07:46:19Z","recommended_products":[],"attributes":[{"name":"Purchase before installed (true\/false)","value":"false","code":"purchase_before_installed"},{"name":"Video Title 1","value":"Protect your files with McAfee\u00ae Antivirus","code":"video_title_1"},{"name":"Allow Gift Message","value":"No","code":"gift_message_available"},{"name":"Product Class","value":"McAfee","code":"product_class"},{"name":"Video URL 1","value":"https:\/\/www.youtube.com\/watch?v=rKEtNTiVApg","code":"video_url_1"},{"name":"App Display Name","value":"McAfee Antivirus","code":"app_display_name"},{"name":"Video Image URL 1","value":"https:\/\/img.youtube.com\/vi\/rKEtNTiVApg\/0.jpg","code":"video_image_url_1"},{"name":"App Internal Name","value":"MCAFEE_QNAP","code":"app_internal_name"},{"name":"Video Title 2","value":" ","code":"video_title_2"},{"name":"Product Page Type","value":"Default","code":"product_page_type"},{"name":"License Activation","value":"<div class=\"qSW-pd-desc\"  id=\"qSW-pd-detail-license\">\n    \n    <iframe class=\"resize_height iframe_license_activation\" id=\"iframe_license_activation\" src=\"https:\/\/docs.qnap.com\/operating-system\/qts\/4.5.x\/zh-cn\/GUID-C6DE86F5-38A3-496E-A872-F833E1E5280D.html\" frameborder=\"0\" allowfullscreen=\"\" width=\"100%\" height=\"100%\" scrolling=\"no\"><\/iframe>\n\n<\/div>","code":"license_activation_info"},{"name":"Product Image Size","value":"Default","code":"product_image_size"},{"name":"Immediate Activate (true\/false)","value":true,"code":"immediate_activate"},{"name":"Extendable","value":true,"code":"extendable"},{"name":"Display Actual Price","value":"Use config","code":"msrp_display_actual_price_type"},{"name":"Upgradeable","value":false,"code":"upgradeable"},{"name":"Extend Check Type","value":"product.product_type","code":"ext_check_type"},{"name":"License type (device or user)","value":"device","code":"type"},{"name":"Device Type","value":"vqts_cld","code":"device_type"},{"name":"Min Version of App","value":"2.0.0","code":"app_min_version"},{"name":"Pre-Gen Key","value":true,"code":"pre_gen_key"},{"name":"Quota (Max_device)","value":"1","code":"quota_device"},{"name":"Perpetual License (true\/false)","value":"false","code":"is_perpetual"},{"name":"Support Subscription(1\/0)","value":true,"code":"is_subscription"},{"name":"Transferable","value":true,"code":"transferable"},{"name":"UI type","value":"Drop-down List","code":"ui_type"},{"name":"Image Label","value":"McAfee Antivirus for QuTScloud","code":"image_label"},{"name":"Is floating","value":true,"code":"is_floating"},{"name":"Small Image Label","value":"McAfee Antivirus for QuTScloud","code":"small_image_label"},{"name":"Allow grace period","value":true,"code":"is_grace"},{"name":"Thumbnail Label","value":"McAfee Antivirus for QuTScloud","code":"thumbnail_label"},{"name":"Grace period given (days)","value":"7","code":"grace_period_days"},{"name":"Online Activate Only","value":false,"code":"online_activate_only"},{"name":"Show Unit Price SKU","value":"LS-MCAFEE-QTSCLD-1Y-EI","code":"shown_unit_price_sku"},{"name":"Product Owner","value":"0","code":"amrolepermissions_owner"},{"name":"Purchase before installed (true\/false)","value":"false","code":"purchase_before_installed"},{"name":"Child Skus","code":"child_skus","value":["LS-MCAFEE-QTSCLD-1Y-EI","LS-MCAFEE-QTSCLD-2Y-EI"]}],"categories":[],"product_class":"McAfee","stockrecords":"","images":[{"id":13951,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/8\/0\/800x800_product_01_mcafee_for_qutscloud_1.png","caption":"","display_order":0,"date_created":"2020-06-29T04:11:35Z","tag":"image","product":2149},{"id":13951,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/8\/0\/800x800_product_01_mcafee_for_qutscloud_1.png","caption":"","display_order":0,"date_created":"2020-06-29T04:11:35Z","tag":"logo","product":2149},{"id":13951,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/8\/0\/800x800_product_01_mcafee_for_qutscloud_1.png","caption":"","display_order":1,"date_created":"2020-06-29T04:11:35Z","tag":"small_image","product":2149},{"id":13951,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/8\/0\/800x800_product_01_mcafee_for_qutscloud_1.png","caption":"","display_order":2,"date_created":"2020-06-29T04:11:35Z","tag":"thumbnail","product":2149},{"id":13951,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/8\/0\/800x800_product_01_mcafee_for_qutscloud_1.png","caption":"","display_order":3,"date_created":"2020-06-29T04:11:35Z","tag":"swatch_image","product":2149},{"id":13642,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/p\/r\/product_logo05_mcafee_w256.png","caption":"","display_order":4,"date_created":"2020-06-29T04:11:35Z","tag":"product_logo","product":2149}],"price":{"currency":"USD","excel_tax":25,"incl_tax":25,"tax":0},"availability":"","agreement":"http:\/\/www.mcafee.com\/eula","is_onshop":true,"product_url":"https:\/\/software.qnap.com\/mcafee-antivirus-for-qutscloud.html"},{"url":"https:\/\/api-software.qnap.com\/api\/qnap-products\/2220","id":2220,"title":"CAYIN MediaSign Player on QuTScloud","short_desc":"<div class=\"value\" itemprop=\"description\">CAYIN MediaSign Player \u53ef\u8ba9\u60a8\u7684 NAS \u652f\u6301\u89c6\u9891\u683c\u5f0f\u8f6c\u6362\u5e76\u6253\u5f00\u56fe\u50cf\u53ca\u89c6\u9891\u683c\u5f0f\uff0c\u5305\u62ec HEIF \u548c HEVC\u3002<br><br><p><img src=\"\/media\/wysiwyg\/third_party\/CAYINMediaSignPlayer\/logo_HEVC_horiz.png\" title=\"HEVC Advance\" alt=\"HEVC Advance\" style=\"margin-top:10px;\"><\/p><\/div>","sku":"VSKU-LS-CAYINPLAYER-QTSCLD","date_created":"2020-11-19T06:45:52Z","date_updated":"2022-03-10T08:16:27Z","recommended_products":[],"attributes":[{"name":"Purchase before installed (true\/false)","value":"true","code":"purchase_before_installed"},{"name":"Ship Bundle Items","value":"Together","code":"shipment_type"},{"name":"Allow Gift Message","value":"No","code":"gift_message_available"},{"name":"Product Class","value":"CAYIN_MediaSign_Play_on_QuTScloud","code":"product_class"},{"name":"App Display Name","value":"CAYIN MediaSign Player","code":"app_display_name"},{"name":"App Internal Name","value":"MediaSignPlayer","code":"app_internal_name"},{"name":"Video Title 2","value":" ","code":"video_title_2"},{"name":"Meta Description","value":"CAYIN MediaSign Player \u662f\u4e00\u79cd\u6613\u4e8e\u4f7f\u7528\u7684 Web \u5a92\u4f53\u64ad\u653e\u5668\uff0c\u4e5f\u7528\u4f5c QNAP NAS \u4e0a\u8fd0\u884c\u7684\u89c6\u9891\u64ad\u653e\u5de5\u5177\u548c\u89c6\u9891\u8f6c\u6362\u5668\u3002","code":"meta_description"},{"name":"Min Version of App","value":"1","code":"app_min_version"},{"name":"License Activation","value":"<div class=\"qSW-pd-desc\"  id=\"qSW-pd-detail-license\">\n    \n    <iframe class=\"resize_height iframe_license_activation\" id=\"iframe_license_activation\" src=\"https:\/\/docs.qnap.com\/operating-system\/qts\/4.5.x\/zh-cn\/GUID-C6DE86F5-38A3-496E-A872-F833E1E5280D.html\" frameborder=\"0\" allowfullscreen=\"\" width=\"100%\" height=\"100%\" scrolling=\"no\"><\/iframe>\n\n<\/div>","code":"license_activation_info"},{"name":"Variant Display Name","value":"CAYIN MediaSign Player on QuTScloud","code":"variant_display_name"},{"name":"Product Image Size","value":"Default","code":"product_image_size"},{"name":"Immediate Activate (true\/false)","value":true,"code":"immediate_activate"},{"name":"Display Actual Price","value":"Use config","code":"msrp_display_actual_price_type"},{"name":"Upgradeable","value":false,"code":"upgradeable"},{"name":"Pre-Gen Key","value":false,"code":"pre_gen_key"},{"name":"Price View","value":"Price Range","code":"price_view"},{"name":"Quota (Max_device)","value":"1","code":"quota_device"},{"name":"Device Type","value":"vqts_cld","code":"device_type"},{"name":"Transferable","value":true,"code":"transferable"},{"name":"Is floating","value":true,"code":"is_floating"},{"name":"Support Organization (true \/ false)","value":false,"code":"support_org"},{"name":"License type (device or user)","value":"device","code":"type"},{"name":"Perpetual License (true\/false)","value":"true","code":"is_perpetual"},{"name":"UI type","value":"Drop-down List","code":"ui_type"},{"name":"Support Subscription(1\/0)","value":false,"code":"is_subscription"},{"name":"Is Bundle","value":false,"code":"is_bundle"},{"name":"Extend Check Type","value":"product.product_type","code":"ext_check_type"},{"name":"Image Label","value":"CAYIN MediaSign Player on QuTScloud","code":"image_label"},{"name":"Extendable","value":true,"code":"extendable"},{"name":"Small Image Label","value":"CAYIN MediaSign Player on QuTScloud","code":"small_image_label"},{"name":"Thumbnail Label","value":"CAYIN MediaSign Player on QuTScloud","code":"thumbnail_label"},{"name":"Self Check Quota","value":false,"code":"is_self_check"},{"name":"Dynamic SKU","value":"1","code":"sku_type"},{"name":"Dynamic Price","value":"0","code":"price_type"},{"name":"Dynamic Weight","value":"0","code":"weight_type"},{"name":"Show Unit Price SKU","value":"LS-CAYINPLAYER-QTSCLD-PLUS-FULL-AG-EI","code":"shown_unit_price_sku"},{"name":"Product Owner","value":"0","code":"amrolepermissions_owner"},{"name":"Packaging Type","value":"None","code":"ts_packaging_type"},{"name":"Purchase before installed (true\/false)","value":"true","code":"purchase_before_installed"},{"name":"Child Skus","code":"child_skus","value":["LS-CAYINPLAYER-QTSCLD-PLUS-FULL-AG-EI","LS-CAYINPLAYER-QTSCLD-BASIC-AG-EI"]}],"categories":[],"product_class":"CAYIN_MediaSign_Play_on_QuTScloud","stockrecords":"","images":[{"id":13855,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/m\/e\/mediasign_player_cover_w800_v2.0_1.jpg","caption":"","display_order":0,"date_created":"2020-11-19T06:45:52Z","tag":"image","product":2220},{"id":13855,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/m\/e\/mediasign_player_cover_w800_v2.0_1.jpg","caption":"","display_order":0,"date_created":"2020-11-19T06:45:52Z","tag":"logo","product":2220},{"id":13855,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/m\/e\/mediasign_player_cover_w800_v2.0_1.jpg","caption":"","display_order":1,"date_created":"2020-11-19T06:45:52Z","tag":"small_image","product":2220},{"id":13855,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/m\/e\/mediasign_player_cover_w800_v2.0_1.jpg","caption":"","display_order":2,"date_created":"2020-11-19T06:45:52Z","tag":"thumbnail","product":2220},{"id":13698,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/c\/a\/cayin_mediasign_player_256_2.png","caption":"","display_order":3,"date_created":"2020-11-19T06:45:52Z","tag":"product_logo","product":2220}],"price":{"currency":"USD","excel_tax":19.99,"incl_tax":19.99,"tax":0},"availability":"","agreement":"","is_onshop":true,"product_url":"https:\/\/software.qnap.com\/cayin-mediasign-player-on-qutscloud.html"},{"url":"https:\/\/api-software.qnap.com\/api\/qnap-products\/2254","id":2254,"title":"Coolocto Membership for QuTScloud","short_desc":"<p>Coolocto - \u7cbe\u5f69\u4e16\u754c\uff0c\u654f\u9510\u628a\u63e1! Coolocto \u63d0\u4f9b\u4e86\u51fa\u8272\u7684\u8de8\u5e73\u53f0\u591a\u5a92\u4f53\u7ba1\u7406\u5e94\u7528\u7a0b\u5e8f\u548c\u4e91\u670d\u52a1\uff0c\u53ef\u9ad8\u6548\u8fdb\u884c\u7fa4\u7ec4\u901a\u4fe1\u548c\u4efb\u52a1\u5b89\u6392\u3002<\/p>\n<p class=\"em-note\">\u8d2d\u4e70\u540e\uff0c\u60a8\u53ef\u4ee5\u76f4\u63a5\u4f7f\u7528 Coolocto \u5e94\u7528\u7a0b\u5e8f\u5c06\u8bbe\u5907\u4e0e\u8bb8\u53ef\u8bc1\u7ed1\u5b9a\u5728\u4e00\u8d77\uff0c\u5e76\u5728 Coolocto \u5b98\u65b9\u7f51\u7ad9(www.coolocto.com)\u4e0a\u7ba1\u7406\u7ed1\u5b9a\u8bbe\u5907\u3002<\/p>","sku":"VSKU-LS-COOLOCTO-QTSCLD","date_created":"2021-05-04T03:12:41Z","date_updated":"2021-11-18T12:35:25Z","recommended_products":[],"attributes":[{"name":"Purchase before installed (true\/false)","value":"true","code":"purchase_before_installed"},{"name":"Allow Gift Message","value":"No","code":"gift_message_available"},{"name":"Product Class","value":"Coolocto Video for QuTScloud","code":"product_class"},{"name":"App Display Name","value":"Coolocto Video for QuTScloud","code":"app_display_name"},{"name":"Transferable","value":true,"code":"transferable"},{"name":"Video Title 2","value":" ","code":"video_title_2"},{"name":"Meta Description","value":"\u89c6\u9891\uff0c\u97f3\u4e50\uff0c\u591a\u5a92\u4f53\uff0c\u79fb\u52a8\uff0c\u5b66\u4e60\uff0c\u7ba1\u7406\uff0c\u5a31\u4e50\uff0c\u4e0b\u8f7d\uff0c\u8bb0\u6cd5\uff0c\u65e5\u5386\uff0c\u8ba1\u5212\uff0c\u4efb\u52a1\uff0c\u63d0\u9192\uff0c\u8fdc\u7a0b\uff0c\u57f9\u8bad","code":"meta_description"},{"name":"Is Bundle","value":false,"code":"is_bundle"},{"name":"Product Image Size","value":"Default","code":"product_image_size"},{"name":"Immediate Activate (true\/false)","value":true,"code":"immediate_activate"},{"name":"Display Actual Price","value":"Use config","code":"msrp_display_actual_price_type"},{"name":"Upgradeable","value":false,"code":"upgradeable"},{"name":"Device Type","value":"vqts_cld, QTS, iOS, Android","code":"device_type"},{"name":"Extendable","value":true,"code":"extendable"},{"name":"Support Organization (true \/ false)","value":false,"code":"support_org"},{"name":"Min Version of App","value":"1.0.0","code":"app_min_version"},{"name":"Perpetual License (true\/false)","value":"FALSE","code":"is_perpetual"},{"name":"License type (device or user)","value":"device","code":"type"},{"name":"Support Subscription(1\/0)","value":true,"code":"is_subscription"},{"name":"Pre-Gen Key","value":false,"code":"pre_gen_key"},{"name":"Quota (Max_device)","value":"1","code":"quota_device"},{"name":"Image Label","value":"Coolocto Standard Membership for QuTScloud","code":"image_label"},{"name":"UI type","value":"Normal","code":"ui_type"},{"name":"Small Image Label","value":"Coolocto Standard Membership for QuTScloud","code":"small_image_label"},{"name":"Variant Display Name","value":"Coolocto Membership for QuTScloud","code":"variant_display_name"},{"name":"Thumbnail Label","value":"Coolocto Standard Membership for QuTScloud","code":"thumbnail_label"},{"name":"Show Unit Price SKU","value":"LS-COOLOCTO-QTSCLD-1Y-EI","code":"shown_unit_price_sku"},{"name":"Product Owner","value":"0","code":"amrolepermissions_owner"},{"name":"Purchase before installed (true\/false)","value":"true","code":"purchase_before_installed"},{"name":"Child Skus","code":"child_skus","value":["LS-COOLOCTO-QTSCLD-1M-EI","LS-COOLOCTO-QTSCLD-1Y-EI"]}],"categories":[],"product_class":"Coolocto Video for QuTScloud","stockrecords":"","images":[{"id":13821,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/c\/o\/coolocto_qutscloud_product_cover.jpg","caption":"","display_order":0,"date_created":"2021-05-04T03:12:41Z","tag":"image","product":2254},{"id":13821,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/c\/o\/coolocto_qutscloud_product_cover.jpg","caption":"","display_order":0,"date_created":"2021-05-04T03:12:41Z","tag":"logo","product":2254},{"id":13821,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/c\/o\/coolocto_qutscloud_product_cover.jpg","caption":"","display_order":1,"date_created":"2021-05-04T03:12:41Z","tag":"small_image","product":2254},{"id":13821,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/c\/o\/coolocto_qutscloud_product_cover.jpg","caption":"","display_order":2,"date_created":"2021-05-04T03:12:41Z","tag":"thumbnail","product":2254},{"id":13821,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/c\/o\/coolocto_qutscloud_product_cover.jpg","caption":"","display_order":3,"date_created":"2021-05-04T03:12:41Z","tag":"swatch_image","product":2254},{"id":13822,"original":"https:\/\/d3i9rzdajqk9em.cloudfront.net\/catalog\/product\/c\/o\/coolocto_product_logo_256_1.png","caption":"","display_order":4,"date_created":"2021-05-04T03:12:41Z","tag":"product_logo","product":2254}],"price":{"currency":"USD","excel_tax":69.9,"incl_tax":69.9,"tax":0},"availability":"","agreement":"","is_onshop":true,"product_url":"https:\/\/software.qnap.com\/coolocto-for-qutscloud.html"}]}');
INSERT INTO "license_keys" VALUES ('L1111-11111-11111-11111-11111','{
	"is_floating":true,
	"ext_check_type":"product.product_type",
	"aw_sarp2_is_used_advanced_pricing":"Use config",
	"app_min_version":"c4.4.2",
	"purchase_before_installed":"false",
	"small_image_label":"QuTScloud 100 Core",
	"is_subscription":true,
	"thumbnail_label":"QuTScloud 100 Core",
	"device_type":"vqts_cld",
	"cpu_limit":"100",
	"external_service":false,
	"plan_title":"1 Core",
	"is_self_check":true,
	"product_image_size":"Default",
	"msrp_display_actual_price_type":"Use config",
	"grace_period_days":"21",
	"gift_message_available":"No",
	"variant_display_name":"QuTScloud 100 Core",
	"pre_gen_key":false,
	"app_display_name":"QuTScloud",
	"quota_device":"1",
	"ui_type":"Drop-down List",
	"expiry_warning_day":"-1",
	"upgradeable":true,
	"transferable":true,
	"amrolepermissions_owner":"0",
	"duration_month":"1",
	"product_class":"vQTS_Cloud",
	"license_activation_info":"<div class=\"qSW-pd-desc\"  id=\"qSW-pd-detail-license\">\n    \n    <iframe class=\"resize_height iframe_license_activation\" id=\"iframe_license_activation\" src=\"https://docs.qnap.com/operating-system/qts/4.5.x/en-us/GUID-C6DE86F5-38A3-496E-A872-F833E1E5280D.html\" frameborder=\"0\" allowfullscreen=\"\" width=\"100%\" height=\"100%\" scrolling=\"no\"></iframe>\n\n</div>",
	"app_internal_name":"vqtscloud",
	"extendable":true,
	"type":"device",
	"is_perpetual":"false",
	"is_bundle":false,
	"immediate_activate":true,
	"support_org":false,
	"image_label":"QuTScloud 100 Core"
}
','{
	"sku":"LS-QUTSCLOUD-1CR-1M-EI",
	"product_type":"vQTS_Cloud",
	"product_id":"2302",
	"categories":[
		"vQTS_Cloud"
	],
	"name":"QuTScloud 100 Core"
}
');
INSERT INTO "license_keys" VALUES ('L8111-11111-11111-11111-11111','{
  "video_title_3":"HybridMount: a file-based cloud storage gateway allows public cloud access like on a local NAS",
  "external_service":false,
  "small_image_label":"HybridMount for QuTScloud",
  "license_name":"HybridMount",
  "extendable":true,
  "license_activation_info":"<div class=\"qSW-pd-desc\"  id=\"qSW-pd-detail-license\">\n    \n    <iframe class=\"resize_height iframe_license_activation\" id=\"iframe_license_activation\" src=\"https://docs.qnap.com/operating-system/qts/4.5.x/zh-cn/GUID-C6DE86F5-38A3-496E-A872-F833E1E5280D.html\" frameborder=\"0\" allowfullscreen=\"\" width=\"100%\" height=\"100%\" scrolling=\"no\"></iframe>\n\n</div>",
  "video_url_3":"https://www.youtube.com/watch?v=cInAKsdIAlM",
  "support_org":true,
  "is_perpetual":false,
  "duration_year":"1",
  "video_title_1":"Multimedia Console x HybridMount: Manage Multimedia Contents in Hybrid Cloud",
  "pre_gen_key":true,
  "grace_period_days":"5",
  "meta_title":"HybridMount for QuTScloud",
  "video_url_1":"https://www.youtube.com/watch?v=vjscizJSItY",
  "image_label":"HybridMount for QuTScloud",
  "immediate_activate":true,
  "connection":"100",
  "msrp_display_actual_price_type":"Use config",
  "variant_feature":"premium",
  "video_image_url_2":"https://img.youtube.com/vi/feMm3mi0wmQ/0.jpg",
  "type":"device",
  "video_image_url_3":"https://img.youtube.com/vi/cInAKsdIAlM/0.jpg",
  "shown_unit_price_sku":"LS-HM-1CON-QTSCLD-1Y-EI",
  "gift_message_available":"No",
  "quota_device":"1",
  "is_grace":true,
  "is_floating":true,
  "is_subscription":true,
  "ext_check_type":"product.product_type",
  "thumbnail_label":"HybridMount for QuTScloud",
  "purchase_before_installed":false,
  "is_bundle":false,
  "amrolepermissions_owner":"0",
  "app_internal_name":"CacheMount",
  "app_min_version":"1.0.1862",
  "transferable":true,
  "video_url_2":"https://www.youtube.com/watch?v=feMm3mi0wmQ",
  "video_image_url_1":"https://img.youtube.com/vi/vjscizJSItY/0.jpg",
  "ui_type":"Drop-down List",
  "product_class":"HybridMount_for_QTScloud",
  "device_type":"vqts_cld",
  "product_image_size":"Default",
  "app_display_name":"HybridMount",
  "product_page_type":"Default",
  "video_title_2":"HybridMount / VJBOD Cloud 雲網關與雲創新｜QNAP 20th Tech day"
}','{
  "categories":[],
  "name":"HybridMount",
  "product_id":"2135",
  "sku":"VSKU-LS-HM-QTSCLD",
  "product_type":"HybridMount_for_QTScloud"
}');
INSERT INTO "license_keys" VALUES ('L1811-11111-11111-11111-11111','{
  "app_min_version":"1.0.0",
  "msrp_display_actual_price_type":"Use config",
  "variant_feature":"premium",
  "upgradeable":false,
  "small_image_label":"Coolocto Standard Membership for QuTScloud",
  "license_name":"Coolocto Video for QuTScloud",
  "product_class":"Coolocto Video for QuTScloud",
  "extendable":true,
  "gift_message_available":"No",
  "quota_device":"1",
  "shown_unit_price_sku":"LS-COOLOCTO-QTSCLD-1Y-EI",
  "app_display_name":"Coolocto Video for QuTScloud",
  "is_subscription":true,
  "thumbnail_label":"Coolocto Standard Membership for QuTScloud",
  "support_org":false,
  "purchase_before_installed":true,
  "is_perpetual":"FALSE",
  "amrolepermissions_owner":"0",
  "is_bundle":false,
  "variant_display_name":"Coolocto Membership for QuTScloud",
  "transferable":true,
  "pre_gen_key":false,
  "device_type":"vqts_cld, QTS, iOS, Android",
  "ui_type":"Normal",
  "type":"device",
  "video_title_2":" ",
  "product_image_size":"Default",
  "meta_description":"视频，音乐，多媒体，移动，学习，管理，娱乐，下载，记法，日历，计划，任务，提醒，远程，培训",
  "image_label":"Coolocto Standard Membership for QuTScloud",
  "immediate_activate":true
}','{
  "categories":[],
  "name":"Coolocto Video for QuTScloud",
  "product_id":"2254",
  "sku":"VSKU-LS-COOLOCTO-QTSCLD",
  "product_type":"Coolocto Video for QuTScloud"
}');
INSERT INTO "license_keys" VALUES ('L1181-11111-11111-11111-11111','{
  "meta_description":"Qsirch 是一款强大的全文搜索引擎，可帮助您在 QuTScloud 中搜索数据。",
  "upgradeable":false,
  "small_image_label":"Qsirch for QuTScloud",
  "license_name":"Qsirch",
  "extendable":true,
  "license_activation_info":"<div class=\"qSW-pd-desc\"  id=\"qSW-pd-detail-license\">\n    \n    <iframe class=\"resize_height iframe_license_activation\" id=\"iframe_license_activation\" src=\"https://docs.qnap.com/operating-system/qts/4.5.x/zh-cn/GUID-C6DE86F5-38A3-496E-A872-F833E1E5280D.html\" frameborder=\"0\" allowfullscreen=\"\" width=\"100%\" height=\"100%\" scrolling=\"no\"></iframe>\n\n</div>",
  "thumbnail_label":"Qsirch for QuTScloud",
  "support_org":true,
  "is_perpetual":false,
  "video_title_1":"New features of Qsirch 4.0: Map Search, Mac Finder Integration and NAS Exploration",
  "pre_gen_key":false,
  "grace_period_days":"1",
  "meta_title":"Qsirch for QuTScloud",
  "video_url_1":"https://www.youtube.com/watch?v=SorojsXHrOo",
  "image_label":"Qsirch for QuTScloud",
  "immediate_activate":true,
  "app_min_version":"4.1.0",
  "msrp_display_actual_price_type":"Use config",
  "variant_feature":"premium",
  "variant_display_name":"Qsirch for QuTScloud",
  "video_image_url_2":"https://img.youtube.com/vi/i_TxxngZyNk/0.jpg",
  "ext_check_type":"product.product_type",
  "product_class":"Qsirch",
  "shown_unit_price_sku":"LS-QSIRCH-QTSCLD-1Y-EI",
  "gift_message_available":"No",
  "quota_device":"1",
  "aw_sarp2_is_used_advanced_pricing":"Use config",
  "is_grace":true,
  "is_subscription":true,
  "is_self_check":true,
  "is_floating":true,
  "purchase_before_installed":true,
  "external_service":false,
  "amrolepermissions_owner":"0",
  "app_internal_name":"Qsirch",
  "is_bundle":false,
  "transferable":true,
  "video_url_2":"https://www.youtube.com/watch?v=i_TxxngZyNk",
  "video_image_url_1":"https://img.youtube.com/vi/SorojsXHrOo/0.jpg",
  "ui_type":"Drop-down List",
  "device_type":"vqts_cld",
  "type":"device",
  "product_image_size":"Default",
  "app_display_name":"Qsirch",
  "product_page_type":"Default",
  "video_title_2":"Get the most from Qsirch''s file indexing and search"
}','{
  "categories":[],
  "name":"Qsirch",
  "product_id":"2030",
  "sku":"VSKU-LS-QSIRCH-QTSCLD",
  "product_type":"Qsirch"
}');
INSERT INTO "license_keys" VALUES ('L1118-11111-11111-11111-11111','{
  "meta_description":"QuMagie 是一种 AI 辅助照片管理应用程序，可识别照片中的人物、物品或主题并自动进行组织。",
  "upgradeable":false,
  "small_image_label":"QuMagie for QuTScloud",
  "license_name":"QuMagie",
  "extendable":true,
  "app_display_name":"QuMagie",
  "thumbnail_label":"QuMagie for QuTScloud",
  "support_org":false,
  "is_perpetual":false,
  "video_title_1":"Explore the brand-new QuMagie",
  "pre_gen_key":false,
  "grace_period_days":"1",
  "video_url_1":"https://www.youtube.com/watch?v=XZOQepLi5MQ",
  "image_label":"QuMagie for QuTScloud",
  "immediate_activate":true,
  "msrp_display_actual_price_type":"Use config",
  "product_class":"QuMagie_for_QTScloud",
  "gift_message_available":"No",
  "quota_device":"1",
  "variant_feature":"premium",
  "is_floating":true,
  "is_subscription":true,
  "is_self_check":true,
  "shown_unit_price_sku":"LS-QUMAGIE-QTSCLD-1Y-EI",
  "type":"device",
  "is_grace":true,
  "amrolepermissions_owner":"0",
  "app_internal_name":"qumagie",
  "device_type":"vqts_cld",
  "transferable":true,
  "external_service":false,
  "video_image_url_1":"https://img.youtube.com/vi/XZOQepLi5MQ/0.jpg",
  "ui_type":"Drop-down List",
  "ext_check_type":"product.product_type",
  "is_bundle":false,
  "product_image_size":"Default",
  "license_activation_info":"<div class=\"qSW-pd-desc\"  id=\"qSW-pd-detail-license\">\n    \n    <iframe class=\"resize_height iframe_license_activation\" id=\"iframe_license_activation\" src=\"https://docs.qnap.com/operating-system/qts/4.5.x/zh-cn/GUID-C6DE86F5-38A3-496E-A872-F833E1E5280D.html\" frameborder=\"0\" allowfullscreen=\"\" width=\"100%\" height=\"100%\" scrolling=\"no\"></iframe>\n\n</div>",
  "product_page_type":"Default",
  "purchase_before_installed":false
}','{
  "categories":[],
  "name":"QuMagie",
  "product_id":"1983",
  "sku":"VSKU-LS-QUMAGIE-QTSCLD",
  "product_type":"QuMagie_for_QTScloud"
}');
INSERT INTO "license_keys" VALUES ('L1111-81111-11111-11111-11111','{
  "video_title_3":"HybridMount / VJBOD Cloud 雲網關與雲創新｜QNAP 20th Tech day",
  "meta_description":"VJBOD Cloud is a block-based storage gateway solution that allows you to backup the storage space on your local NAS using cloud space from cloud services providers such as Amazon, Azure, and Google Cloud.",
  "upgradeable":false,
  "small_image_label":"VJBOD Cloud for QuTScloud",
  "license_name":"VJBOD Cloud",
  "extendable":true,
  "space":"100",
  "license_activation_info":"<div class=\"qSW-pd-desc\"  id=\"qSW-pd-detail-license\">\n    \n    <iframe class=\"resize_height iframe_license_activation\" id=\"iframe_license_activation\" src=\"https://docs.qnap.com/operating-system/qts/4.5.x/zh-cn/GUID-C6DE86F5-38A3-496E-A872-F833E1E5280D.html\" frameborder=\"0\" allowfullscreen=\"\" width=\"100%\" height=\"100%\" scrolling=\"no\"></iframe>\n\n</div>",
  "video_url_3":"https://www.youtube.com/watch?v=feMm3mi0wmQ",
  "support_org":false,
  "is_perpetual":false,
  "video_title_1":"QNAP VJBOD (Virtual JBOD) for maximized sharing benefits",
  "pre_gen_key":false,
  "grace_period_days":"1",
  "video_url_1":"https://www.youtube.com/watch?v=iEUJv-ke4dE",
  "image_label":"VJBOD Cloud for QuTScloud",
  "immediate_activate":true,
  "app_min_version":"1.0.0",
  "variant_feature":"premium",
  "msrp_display_actual_price_type":"Use config",
  "is_bundle":false,
  "shown_unit_price_sku":"LS-VJBODCLOUD-QTSCLD-4C-1Y-EI",
  "video_image_url_2":"https://img.youtube.com/vi/1Zsr7eW2xaE/0.jpg",
  "external_service":false,
  "product_class":"VJBOD",
  "is_grace":true,
  "gift_message_available":"No",
  "quota_device":"1",
  "aw_sarp2_is_used_advanced_pricing":"Use config",
  "is_floating":true,
  "is_subscription":true,
  "is_self_check":true,
  "ext_check_type":"product.product_type",
  "purchase_before_installed":false,
  "thumbnail_label":"VJBOD Cloud for QuTScloud",
  "amrolepermissions_owner":"0",
  "app_internal_name":"VJBOD_Cloud_Plug-in",
  "video_image_url_3":"https://img.youtube.com/vi/feMm3mi0wmQ/0.jpg",
  "transferable":true,
  "video_url_2":"https://www.youtube.com/watch?v=1Zsr7eW2xaE",
  "video_image_url_1":"https://img.youtube.com/vi/iEUJv-ke4dE/0.jpg",
  "ui_type":"Drop-down List",
  "type":"device",
  "app_display_name":"VJBOD Cloud",
  "product_image_size":"Default",
  "video_title_2":"Introducing VJBOD Cloud: The block-based cloud storage gateway",
  "product_page_type":"Default",
  "device_type":"vqts_cld"
}','{
  "categories":[],
  "name":"VJBOD Cloud",
  "product_id":"2142",
  "sku":"VSKU-LS-VJBODCLOUD-QTSCLD",
  "product_type":"VJBOD"
}');
INSERT INTO "license_keys" VALUES ('L1111-18111-11111-11111-11111','{
  "upgradeable":false,
  "small_image_label":"McAfee Antivirus for QuTScloud",
  "license_name":"McAfee Antivirus",
  "extendable":true,
  "app_display_name":"McAfee Antivirus",
  "thumbnail_label":"McAfee Antivirus for QuTScloud",
  "is_perpetual":false,
  "video_title_1":"Protect your files with McAfee® Antivirus",
  "pre_gen_key":true,
  "grace_period_days":"7",
  "video_url_1":"https://www.youtube.com/watch?v=rKEtNTiVApg",
  "image_label":"McAfee Antivirus for QuTScloud",
  "immediate_activate":true,
  "app_min_version":"2.0.0",
  "msrp_display_actual_price_type":"Use config",
  "product_class":"McAfee",
  "gift_message_available":"No",
  "quota_device":"1",
  "variant_feature":"premium",
  "is_subscription":true,
  "license_activation_info":"<div class=\"qSW-pd-desc\"  id=\"qSW-pd-detail-license\">\n    \n    <iframe class=\"resize_height iframe_license_activation\" id=\"iframe_license_activation\" src=\"https://docs.qnap.com/operating-system/qts/4.5.x/zh-cn/GUID-C6DE86F5-38A3-496E-A872-F833E1E5280D.html\" frameborder=\"0\" allowfullscreen=\"\" width=\"100%\" height=\"100%\" scrolling=\"no\"></iframe>\n\n</div>",
  "shown_unit_price_sku":"LS-MCAFEE-QTSCLD-1Y-EI",
  "purchase_before_installed":false,
  "online_activate_only":false,
  "amrolepermissions_owner":"0",
  "app_internal_name":"MCAFEE_QNAP",
  "type":"device",
  "ext_check_type":"product.product_type",
  "is_grace":true,
  "video_image_url_1":"https://img.youtube.com/vi/rKEtNTiVApg/0.jpg",
  "ui_type":"Drop-down List",
  "is_floating":true,
  "transferable":true,
  "product_image_size":"Default",
  "video_title_2":" ",
  "product_page_type":"Default",
  "device_type":"vqts_cld"
}','{
  "categories":[],
  "name":"McAfee Antivirus",
  "product_id":"2149",
  "sku":"VSKU-LS-MCAFEE-QTSCLD",
  "product_type":"McAfee"
}');
INSERT INTO "license_keys" VALUES ('L1111-11811-11111-11111-11111','{
  "shipment_type":"Together",
  "meta_description":"CAYIN MediaSign Player 是一种易于使用的 Web 媒体播放器，也用作 QNAP NAS 上运行的视频播放工具和视频转换器。",
  "upgradeable":false,
  "small_image_label":"CAYIN MediaSign Player on QuTScloud",
  "license_name":"CAYIN MediaSign Player",
  "extendable":true,
  "app_display_name":"CAYIN MediaSign Player",
  "thumbnail_label":"CAYIN MediaSign Player on QuTScloud",
  "support_org":false,
  "is_perpetual":true,
  "sku_type":"1",
  "pre_gen_key":false,
  "image_label":"CAYIN MediaSign Player on QuTScloud",
  "immediate_activate":true,
  "app_min_version":"1",
  "msrp_display_actual_price_type":"Use config",
  "variant_display_name":"CAYIN MediaSign Player on QuTScloud",
  "variant_feature":"premium",
  "product_class":"CAYIN_MediaSign_Play_on_QuTScloud",
  "transcoding":"1",
  "is_floating":true,
  "quota_device":"1",
  "video_title_2":" ",
  "price_type":"0",
  "is_subscription":false,
  "is_self_check":false,
  "shown_unit_price_sku":"LS-CAYINPLAYER-QTSCLD-PLUS-FULL-AG-EI",
  "purchase_before_installed":true,
  "weight_type":"0",
  "amrolepermissions_owner":"0",
  "app_internal_name":"MediaSignPlayer",
  "price_view":"Price Range",
  "transferable":true,
  "ext_check_type":"product.product_type",
  "license_activation_info":"<div class=\"qSW-pd-desc\"  id=\"qSW-pd-detail-license\">\n    \n    <iframe class=\"resize_height iframe_license_activation\" id=\"iframe_license_activation\" src=\"https://docs.qnap.com/operating-system/qts/4.5.x/zh-cn/GUID-C6DE86F5-38A3-496E-A872-F833E1E5280D.html\" frameborder=\"0\" allowfullscreen=\"\" width=\"100%\" height=\"100%\" scrolling=\"no\"></iframe>\n\n</div>",
  "ui_type":"Drop-down List",
  "gift_message_available":"No",
  "is_bundle":false,
  "product_image_size":"Default",
  "ts_packaging_type":"None",
  "type":"device",
  "device_type":"vqts_cld"
}','{
  "categories":[],
  "name":"CAYIN MediaSign Player",
  "product_id":"2220",
  "sku":"VSKU-LS-CAYINPLAYER-QTSCLD",
  "product_type":"CAYIN_MediaSign_Play_on_QuTScloud"
}');
INSERT INTO "license_keys" VALUES ('L1111-11181-11111-11111-11111','{
  "meta_description":"Boxafe 是一款功能全面的企业备份解决方案，适用于 QNAP Cloud NAS 中的 Google™ G Suite 和 Microsoft® Office 365®。",
  "upgradeable":false,
  "small_image_label":"Boxafe for QuTScloud",
  "license_name":"Boxafe",
  "extendable":true,
  "app_display_name":"Boxafe",
  "thumbnail_label":"Boxafe for QuTScloud",
  "support_org":false,
  "is_perpetual":false,
  "video_title_1":"Boxafe: A business backup solution for Google™ G Suite and Microsoft® Office 365®",
  "pre_gen_key":false,
  "grace_period_days":"1",
  "video_url_1":"https://www.youtube.com/watch?v=bWEq0rs-yZs",
  "image_label":"Boxafe for QuTScloud",
  "immediate_activate":true,
  "app_min_version":"1.0.0",
  "msrp_display_actual_price_type":"Use config",
  "variant_display_name":"Boxafe for QuTScloud",
  "product_class":"Boxafe_for_QuTScloud",
  "variant_feature":"premium",
  "gift_message_available":"No",
  "quota_device":"1",
  "purchase_before_installed":true,
  "is_floating":true,
  "is_subscription":true,
  "is_self_check":true,
  "shown_unit_price_sku":"LS-BOXAFE-QTSCLD-1Y-EI",
  "type":"device",
  "is_grace":true,
  "amrolepermissions_owner":"0",
  "app_internal_name":"boxafe",
  "external_service":false,
  "transferable":true,
  "ext_check_type":"product.product_type",
  "video_image_url_1":"https://img.youtube.com/vi/bWEq0rs-yZs/0.jpg",
  "ui_type":"Drop-down List",
  "is_bundle":false,
  "license_activation_info":"<div class=\"qSW-pd-desc\"  id=\"qSW-pd-detail-license\">\n    \n    <iframe class=\"resize_height iframe_license_activation\" id=\"iframe_license_activation\" src=\"https://docs.qnap.com/operating-system/qts/4.5.x/zh-cn/GUID-C6DE86F5-38A3-496E-A872-F833E1E5280D.html\" frameborder=\"0\" allowfullscreen=\"\" width=\"100%\" height=\"100%\" scrolling=\"no\"></iframe>\n\n</div>",
  "product_image_size":"Default",
  "video_title_2":" ",
  "product_page_type":"Default",
  "device_type":"vqts_cld"
}','{
  "categories":[],
  "name":"Boxafe",
  "product_id":"2053",
  "sku":"VSKU-LS-BOXAFE-QTSCLD",
  "product_type":"Boxafe_for_QuTScloud"
}');
INSERT INTO "license_keys" VALUES ('L1111-11118-11111-11111-11111','{
  "meta_description":"借助 QNAP QmailAgent，可以安全地集中管理，并轻松备份多个电子邮件帐户。",
  "upgradeable":false,
  "small_image_label":"QmailAgent for QuTScloud",
  "license_name":"QmailAgent",
  "extendable":true,
  "app_display_name":"QmailAgent",
  "thumbnail_label":"QmailAgent for QuTScloud",
  "support_org":false,
  "is_perpetual":false,
  "video_title_1":"QNAP QmailAgent - A mailroom center for your private cloud",
  "pre_gen_key":false,
  "grace_period_days":"1",
  "video_url_1":"https://www.youtube.com/watch?v=oAVSHGPIIYU",
  "image_label":"QmailAgent for QuTScloud",
  "immediate_activate":true,
  "app_min_version":"2.3.0",
  "msrp_display_actual_price_type":"Use config",
  "variant_display_name":"QmailAgent for QuTScloud",
  "product_class":"QmailAgent_for_QuTScloud",
  "ext_check_type":"product.product_type",
  "gift_message_available":"No",
  "quota_device":"1",
  "shown_unit_price_sku":"LS-QMAIL-QTSCLD-1Y-EI",
  "is_grace":true,
  "is_subscription":true,
  "is_self_check":true,
  "is_floating":true,
  "purchase_before_installed":true,
  "external_service":false,
  "amrolepermissions_owner":"0",
  "app_internal_name":"qmail",
  "is_bundle":false,
  "variant_feature":"premium",
  "transferable":true,
  "video_image_url_1":"https://img.youtube.com/vi/oAVSHGPIIYU/0.jpg",
  "ui_type":"Drop-down List",
  "license_activation_info":"<div class=\"qSW-pd-desc\"  id=\"qSW-pd-detail-license\">\n    \n    <iframe class=\"resize_height iframe_license_activation\" id=\"iframe_license_activation\" src=\"https://docs.qnap.com/operating-system/qts/4.5.x/zh-cn/GUID-C6DE86F5-38A3-496E-A872-F833E1E5280D.html\" frameborder=\"0\" allowfullscreen=\"\" width=\"100%\" height=\"100%\" scrolling=\"no\"></iframe>\n\n</div>",
  "type":"device",
  "product_image_size":"Default",
  "video_title_2":" ",
  "product_page_type":"Default",
  "device_type":"vqts_cld"
}','{
  "categories":[],
  "name":"QmailAgent",
  "product_id":"2075",
  "sku":"VSKU-LS-QMAIL-QTSCLD",
  "product_type":"QmailAgent_for_QuTScloud"
}');
INSERT INTO "license_keys" VALUES ('L1111-11111-81111-11111-11111','{
  "meta_description":"OCR Converter 将基于文本的图像转换为可编辑文档。您可以指定输出语言和文件格式，并创建转换计划以提高效率。",
  "small_image_label":"OCR Converter for QuTScloud",
  "license_name":"OCR Converter",
  "extendable":true,
  "app_display_name":"OCR Converter",
  "thumbnail_label":"OCR Converter for QuTScloud",
  "support_org":false,
  "is_perpetual":false,
  "video_title_1":"Use Text Editor to edit source code, digitize files with OCR Converter",
  "pre_gen_key":false,
  "grace_period_days":"1",
  "video_url_1":"https://www.youtube.com/watch?v=URTAGHARww8",
  "image_label":"OCR Converter for QuTScloud",
  "immediate_activate":true,
  "app_min_version":"1.2.0",
  "msrp_display_actual_price_type":"Use config",
  "product_class":"OCRConverter",
  "gift_message_available":"No",
  "quota_device":"1",
  "variant_feature":"premium",
  "is_subscription":true,
  "is_self_check":true,
  "is_grace":true,
  "type":"device",
  "shown_unit_price_sku":"LS-OCR-QTSCLD-1Y-EI",
  "amrolepermissions_owner":"0",
  "app_internal_name":"OCR_Converter",
  "is_floating":true,
  "transferable":true,
  "ext_check_type":"product.product_type",
  "video_image_url_1":"https://img.youtube.com/vi/URTAGHARww8/0.jpg",
  "ui_type":"Drop-down List",
  "external_service":false,
  "is_bundle":false,
  "product_image_size":"Default",
  "purchase_before_installed":true,
  "product_page_type":"Default",
  "device_type":"vqts_cld"
}','{
  "categories":[],
  "name":"OCR Converter",
  "product_id":"2024",
  "sku":"VSKU-LS-OCR-QTSCLD",
  "product_type":"OCRConverter"
}');
INSERT INTO "license_keys" VALUES ('L1111-11111-18111-11111-11111','{
  "meta_description":"Qfiling 可为您自动完成文件组织任务。 您只需将文件分类并制定计划，其余操作均由 Qfiling 完成。 简单、智能、高效!",
  "upgradeable":true,
  "small_image_label":"Qfiling for QuTScloud",
  "license_name":"Qfiling for QuTScloud Upgrade",
  "extendable":true,
  "app_display_name":"Qfiling for QuTScloud Upgrade",
  "thumbnail_label":"Qfiling for QuTScloud",
  "support_org":false,
  "is_perpetual":false,
  "video_title_1":"Simplified file organization with Qfiling",
  "pre_gen_key":false,
  "grace_period_days":"1",
  "video_url_1":"https://www.youtube.com/watch?v=w-64XPxIS7g",
  "image_label":"Qfiling for QuTScloud",
  "immediate_activate":true,
  "app_min_version":"3.0.0",
  "msrp_display_actual_price_type":"Use config",
  "video_image_url_2":"https://img.youtube.com/vi/WvsIkVeUHJM/0.jpg",
  "variant_feature":"premium",
  "product_class":"Qfiling",
  "ext_check_type":"product.product_type",
  "gift_message_available":"No",
  "quota_device":"1",
  "shown_unit_price_sku":"LS-QFILING-QTSCLD-1Y-EI",
  "is_grace":true,
  "is_subscription":true,
  "is_self_check":true,
  "is_floating":true,
  "purchase_before_installed":true,
  "external_service":false,
  "amrolepermissions_owner":"0",
  "app_internal_name":"Qfiling",
  "video_url_2":"https://www.youtube.com/watch?v=WvsIkVeUHJM",
  "transferable":true,
  "is_bundle":false,
  "video_image_url_1":"https://img.youtube.com/vi/w-64XPxIS7g/0.jpg",
  "ui_type":"Drop-down List",
  "license_activation_info":"<div class=\"qSW-pd-desc\"  id=\"qSW-pd-detail-license\">\n    \n    <iframe class=\"resize_height iframe_license_activation\" id=\"iframe_license_activation\" src=\"https://docs.qnap.com/operating-system/qts/4.5.x/zh-cn/GUID-C6DE86F5-38A3-496E-A872-F833E1E5280D.html\" frameborder=\"0\" allowfullscreen=\"\" width=\"100%\" height=\"100%\" scrolling=\"no\"></iframe>\n\n</div>",
  "type":"device",
  "product_image_size":"Default",
  "video_title_2":"Qfiling 2.1 explained: Browse and share images via Image2PDF file editing modules",
  "product_page_type":"Default",
  "device_type":"vqts_cld"
}','{
  "categories":[],
  "name":"Qfiling for QuTScloud Upgrade",
  "product_id":"2027",
  "sku":"VSKU-LS-QFILING-QTSCLD",
  "product_type":"Qfiling"
}');
COMMIT;
