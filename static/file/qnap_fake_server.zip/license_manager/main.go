// licensemanager project main.go
package main

import (
	"flag"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"net/url"
	"strings"

	"github.com/gin-gonic/gin"
)

func oauth_token(c *gin.Context) {
	c.Writer.Header().Set("Content-Type", "application/json")
	c.String(http.StatusOK, "%s", access_token)
}

func license_key_info(c *gin.Context) {
	key := strings.ToUpper(c.Query("license_key"))
	device_id := c.GetHeader("X-QNAP-DIGEST")

	log.Println(key, device_id)

	lic := new_license(key, device_id)
	lic.delete_seat()
	err := lic.license_seat_info()
	if err != nil {
		log.Println(key, device_id)
		c.JSON(http.StatusOK, gin.H{
			"code":    -1,
			"message": err.Error(),
		})
		return
	}
	c.JSON(http.StatusOK, gin.H{
		"code":    0,
		"message": "OK.",
		"result":  []DETAIL_INFO{lic.detail_info},
	})

}

func activation(c *gin.Context) {
	key := strings.ToUpper(c.PostForm("license_key"))
	device_id := c.GetHeader("X-QNAP-DIGEST")
	lic := new_license(key, device_id)

	dif, err := c.FormFile("dif")
	if err != nil {
		c.JSON(http.StatusOK, gin.H{
			"code":    -1,
			"message": err.Error(),
		})
		return
	}
	f, err := dif.Open()
	if err != nil {
		c.JSON(http.StatusOK, gin.H{
			"code":    -1,
			"message": err.Error(),
		})
		return
	}

	dif_str, err := ioutil.ReadAll(f)
	if err != nil {
		c.JSON(http.StatusOK, gin.H{
			"code":    -1,
			"message": err.Error(),
		})
		return
	}
	err = lic.license_active(string(dif_str))
	if err != nil {
		c.JSON(http.StatusOK, gin.H{
			"code":    -1,
			"message": err.Error(),
		})
		return
	}
	c.JSON(http.StatusOK, gin.H{
		"code":    0,
		"message": "OK.",
		"result":  myaddr + lic.detail_info.SeatsInfo.LifDownloadPath,
	})
}

func download_pkg(c *gin.Context) {
	key := strings.ToUpper(c.Query("license_key"))
	device_id := c.GetHeader("X-QNAP-DIGEST")
	lic := new_license(key, device_id)
	err := lic.license_download()
	if err != nil {
		c.JSON(http.StatusOK, gin.H{
			"code":    -1,
			"message": err.Error(),
		})
		return
	}
	c.Data(http.StatusOK, "application/octet-stream", []byte(lic.Rawlif))
}

func installed(c *gin.Context) {
	j := make(map[string]string)
	data, _ := c.GetRawData()
	data_str, _ := url.QueryUnescape(string(data))
	json.Unmarshal([]byte(data_str), &j)
	token, ok := j["floating_uuid"]
	log.Println(data_str)
	if !ok {
		if _,ok := j["mac"]; ok {
			device_id := c.GetHeader("X-QNAP-DIGEST")
			infos := all_license_seat_info(device_id)
			c.JSON(http.StatusOK, gin.H{
				"message": "OK.",
				"code":    0,
				"result":  infos,
			})		
			return
		}
		c.JSON(http.StatusOK, gin.H{
			"code":    -1,
			"message": "no floating_uuid",
		})
		return
	}
	l, err := new_license_from_token(token)
	if err != nil {
		device_id := c.GetHeader("X-QNAP-DIGEST")
		infos := all_license_seat_info(device_id)
		c.JSON(http.StatusOK, gin.H{
                                "message": "OK.",
                                "code":    0,
                                "result":  infos,
                })

		return
	}
	err = l.license_seat_info()
	if err != nil {
		c.JSON(http.StatusOK, gin.H{
			"code":    -1,
			"message": err.Error(),
		})
		return
	}
	c.JSON(http.StatusOK, gin.H{
		"code":    0,
		"message": "OK.",
		"result":  []DETAIL_INFO{l.detail_info, l.detail_info},
	})
}

func issue_token(c *gin.Context) {
	key := strings.ToUpper(c.PostForm("license_key"))
	device_id := c.GetHeader("X-QNAP-DIGEST")
	lic := new_license(key, device_id)

	dif, err := c.FormFile("dif")
	if err != nil {
		c.JSON(http.StatusOK, gin.H{
			"code":    -1,
			"message": err.Error(),
		})
		return
	}
	f, err := dif.Open()
	if err != nil {
		c.JSON(http.StatusOK, gin.H{
			"code":    -1,
			"message": err.Error(),
		})
		return
	}

	dif_str, err := ioutil.ReadAll(f)
	if err != nil {
		c.JSON(http.StatusOK, gin.H{
			"code":    -1,
			"message": err.Error(),
		})
		return
	}

	err = lic.issue_token(string(dif_str))
	if err != nil {
		c.JSON(http.StatusOK, gin.H{
			"code":    -1,
			"message": err.Error(),
		})
		return
	}
	c.JSON(http.StatusOK, gin.H{
		"code":    0,
		"message": "OK.",
		"result":  myaddr + lic.detail_info.SeatsInfo.LifDownloadPath,
	})
}

func list_license(c *gin.Context) {
}
func device_count(c *gin.Context) {
	count := active_devices()
	c.String(http.StatusOK, fmt.Sprintf("%d/%d", count, dev_limit))
}

func public_key(c *gin.Context) {
	pubkey, err := ioutil.ReadFile("public.pem")
	if err != nil {
		c.String(http.StatusInternalServerError, "Key not found")
		return
	}
	c.String(http.StatusOK, string(pubkey))
}

func product_list(c *gin.Context) {
	pro_list, err := ioutil.ReadFile("product_list")
	if err != nil {
		c.String(http.StatusInternalServerError, "product_list not found")
		return
	}
	c.Data(http.StatusOK, "application/json", pro_list)
}

var myaddr string = "http://132.145.94.147"

func main() {
	flag.Parse()

	router := gin.Default()
	router.NoRoute(func(c *gin.Context) {
    c.JSON(404, gin.H{"code": -1, "message": "Page not found"})
})

	router.POST("/oauth/token", oauth_token)
	router.GET("/v1.0/license/license_key_info", license_key_info)
	router.POST("/v1.1/license/:license_id/activation", activation)
	router.GET("/v1.2/license/:license_id/download_pkg", download_pkg)
	router.POST("/v1.1/license/device/installed", installed)
	router.POST("/v1.1/license/:license_id/issue_token", issue_token)

	router.GET("/device_count", device_count)
	router.GET("/licenses", list_license)
	router.GET("/public_key", public_key)
	router.GET("/product_list", product_list)
	router.GET("/api/qnap-products", product_list)

	router.Run(":80")

}
