// misc
package main

import (
	"flag"
	"bytes"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"math/rand"
	"os/exec"
	"time"

	"github.com/google/uuid"

	"github.com/jmoiron/sqlx"
	_ "github.com/mattn/go-sqlite3"
)

type device_license struct {
	License_key    string `db:"license_key"`
	Device_id      string `db:"device_id"`
	Floating_token string `db:"floating_token"`

	Dif         string `db:"dif"` // dif data json
	Lif         string `db:"lif"` // lif data json
	Rawdif      string `db:"rawdif"`
	Rawlif      string `db:"rawlif"`
	Detail_info string `db:"detail_info"`

	Attr    string `db:"attributes"`
	Product string `db:"product"`

	attr        map[string]interface{}
	product     Product
	dif         DIF
	lif         LIF
	rawdif      RAW_DIF
	rawlif      RAW_LIF
	detail_info DETAIL_INFO
}

func popen(args []string, stdin []byte) (stdout []byte, err error) {
	stdin_reader := bytes.NewReader(stdin)
	stdout_buf := new(bytes.Buffer)
	cmd := exec.Command(args[0], args[1:]...)

	cmd.Stdin = stdin_reader
	cmd.Stdout = stdout_buf

	//log.Println(args)
	//log.Println(base64.StdEncoding.EncodeToString(stdin))

	cmd.Run()
	stdout = stdout_buf.Bytes()
	return
}

func (l *device_license) encrypt_sign_lif() (err error) {
	l.rawlif.Nonce = uuid.NewString()
	encrypt_cmd := []string{
		"openssl",
		"enc",
		"-e",
		"-aes-256-cbc",
		"-md",
		"md5",
		"-k",
		l.rawlif.Nonce,
		"-salt",
	}

	sign_cmd := []string{
		"openssl",
		"dgst",
		"-sha256",
		"-sign",
		"private.pem",
	}

	lif_json := []byte(l.Lif)
	lif_data, err := popen(encrypt_cmd, lif_json)
	if err != nil {
		return
	}
	lif_sgin, err := popen(sign_cmd, lif_data)
	if err != nil {
		return
	}
	l.rawlif.Data = base64.StdEncoding.EncodeToString(lif_data)
	l.rawlif.Signature = base64.StdEncoding.EncodeToString(lif_sgin)

	rawlif_json, err := json.Marshal(l.rawlif)
	if err != nil {
		return
	}
	l.Rawlif = string(rawlif_json)

	return
}

func (l *device_license) decrypt_dif() (err error) {
	dif_data, err := base64.StdEncoding.DecodeString(l.rawdif.Data)
	if err != nil {
		return
	}

	decrypt_cmd := []string{
		"openssl",
		"enc",
		"-d",
		"-aes-256-cbc",
		"-md",
		"md5",
		"-k",
		l.rawdif.Nonce,
		"-salt",
	}
	dif_json, err := popen(decrypt_cmd, dif_data)
	if err != nil {
		log.Println(err)
		return
	}
	err = json.Unmarshal(dif_json, &l.dif)
	if err != nil {
		log.Println(err)
		return
	}
	return
}

func new_license_from_token(token string) (l *device_license, err error) {
	l = &device_license{}
	err = db.Get(&l.License_key, "select license_key from floating_tokens where floating_token=$1 limit 1", token)
	if err != nil {
		log.Println(err)
	}
	err = db.Get(&l.Device_id, "select device_id from floating_tokens where floating_token=$1 limit 1", token)
	if err != nil {
		log.Println(err)
	}
	return
}

func new_license(key, device string) *device_license {
	log.Println(key, device)
	return &device_license{
		License_key: key,
		Device_id:   device,
	}

}

func (l *device_license) read_license_attr() (err error) {
	if l.Attr != "" {
		return
	}
	log.Println(l.License_key)
	err = db.Get(&l.Attr, "select attributes from license_keys where license_key=$1 limit 1", l.License_key)
	if err != nil {
		log.Println(err)
		return
	}
	err = db.Get(&l.Product, "select product from license_keys where license_key=$1 limit 1", l.License_key)
	if err != nil {
		log.Println(err)
		return
	}
	err = json.Unmarshal([]byte(l.Attr), &l.attr)
	if err != nil {
		log.Println(err)
		return
	}
	l.attr["is_subscription"] = false
	//log.Println(l.attr["license_activation_info"])
	err = json.Unmarshal([]byte(l.Product), &l.product)
	if err != nil {
		log.Println(err)
		return
	}
	return
}

func (l *device_license) create_empty_seat_info() (err error) {
	var detail_info_json string
	err = db.Get(&detail_info_json, "select value from templates where `name`='license_info' limit 1")
	if err != nil {
		log.Println(err)
		return
	}
	var detail_info DETAIL_INFO
	err = json.Unmarshal([]byte(detail_info_json), &detail_info)
	if err != nil {
		log.Println(err)
		return
	}

	err = l.read_license_attr()
	if err != nil {
		log.Println(err)
		return
	}

	detail_info.Attributes = l.attr
	detail_info.AppMinVersion, _ = l.attr["app_min_version"].(string)
	detail_info.Product = l.product
	detail_info.AppDisplayName, _ = l.attr["app_display_name"].(string)
	detail_info.AppInternalName, _ = l.attr["app_internal_name"].(string)
	detail_info.CreatedAt = time.Now()
	detail_info.ExpiresAt = time.Now().AddDate(10, 0, 0)
	detail_info.LicenseKey = l.License_key
	detail_info.LicenseID = random_string(24)
	detail_info.UpdatedAt = time.Now()
	detail_info.ActivatedAt = time.Now()
	detail_info.LicenseCredit[0].AppliedDate = time.Now()
	detail_info.LicenseName = l.product.Name
	detail_info.Available_seats = 1
	detail_info.RemainDays = 365 * 10

	l.detail_info = detail_info
	detail_info_bytes, err := json.Marshal(detail_info)
	if err != nil {
		log.Println(err)
		return
	}
	l.Detail_info = string(detail_info_bytes)
	l.Floating_token = uuid.NewString()
	_, err = db.Exec("insert into devices (license_key, device_id, floating_token, detail_info) values ($1, $2, $3, $4)",
		l.License_key, l.Device_id, l.Floating_token, l.Detail_info)
	if err != nil {
		log.Println(err)
		return
	}
	return
}

func all_license_seat_info(device_id string) []DETAIL_INFO {
	infos := []DETAIL_INFO{}
	db.Select(&infos, "select detail_info from devices where device_id=$1", device_id)
	return infos
}

func (l *device_license) delete_seat() {
	db.Exec("delete from devices where license_key=$1 and device_id=$2", l.License_key, l.Device_id)
	//db.Exec("delete from floating_tokens where license_key=$1 and device_id=$2", l.License_key, l.Device_id)
}

func (l *device_license) license_seat_info() (err error) {
	var count int
	db.Get(&count, "select count(DISTINCT device_id) from floating_tokens")
	if count == 0 {
		dev_num := active_devices()
		if dev_num > dev_limit {
			err = errors.New("device reach limit")
		}
	}
	err = db.Get(&l.Detail_info, "select detail_info from devices where license_key=$1 and device_id=$2 limit 1",
		l.License_key, l.Device_id)
	if err != nil {
		log.Println(err)
	}
	if l.Detail_info == "" {
		err = l.create_empty_seat_info()
		if err != nil {
			log.Println(err)
		}
		return
	}
	err = json.Unmarshal([]byte(l.Detail_info), &l.detail_info)
	if err != nil {
		log.Println(err)
	}
	return
}

func (l *device_license) generate_lif() (err error) {
	err = json.Unmarshal([]byte(l.Dif), &l.rawdif)
	if err != nil {
		log.Println(err)
		return
	}
	err = l.decrypt_dif()
	if err != nil {
		log.Println(err)
		return
	}

	if l.Floating_token == "" {
		err = db.Get(&l.Floating_token, "select floating_token from devices where license_key=$1 and device_id=$2",
			l.License_key, l.Device_id)
		if err != nil {
			log.Println(err)
			return
		}
	}
	err = l.read_license_attr()
	if err != nil {
		log.Println(err)
		return
	}
	l.lif.LicenseInfo.Attributes = l.attr
	l.lif.LicenseInfo.AppDisplayName = l.detail_info.AppDisplayName
	l.lif.LicenseInfo.AppInternalName = l.detail_info.AppInternalName
	l.lif.LicenseInfo.AppliedAt = l.detail_info.CreatedAt.Add(time.Hour).Format("2006-01-02 15:04:05.000000")
	l.lif.LicenseInfo.Sku = l.product.Sku
	l.lif.LicenseInfo.ProductType = l.product.ProductType
	l.lif.LicenseInfo.ProductID = l.product.ProductID
	l.lif.LicenseInfo.ValidFrom = l.detail_info.CreatedAt.Format("2006-01-02 15:04:05.000000")
	if l.lif.LicenseInfo.AppInternalName == "qmail" {
		l.lif.LicenseInfo.ValidUntil = l.detail_info.ExpiresAt.Format("2006-01-02 15:04:05.000000")
	} else {
		l.lif.LicenseInfo.ValidUntil = "None"
	}
	l.lif.LicenseInfo.Name = l.product.Name
	l.lif.LicenseInfo.Categories = l.product.Categories
	l.lif.LicenseInfo.Owner = l.detail_info.Owner
	if _, ok := l.attr["license_name"].(string); ok {
		l.lif.LicenseInfo.LicenseName = l.attr["license_name"].(string)
	}

	l.lif.FloatingUUID = l.Floating_token
	l.lif.CreatedAt = l.dif.CreatedAt
	l.lif.FloatingToken = "12345678"
	l.lif.DifID = l.dif.ID
	l.lif.DifSignature = l.rawdif.Signature
	l.lif.LicenseID = l.detail_info.LicenseID
	l.lif.LicenseCheckPeriod = 43200
	l.lif.ID = uuid.NewString()
	l.lif.HwInfo = l.dif.HwInfo

	l.detail_info.SeatsInfo.AvailableSeats = 0
	l.detail_info.SeatsInfo.TotalActivated = 1
	l.detail_info.SeatsInfo.LifDownloadPath = "/v1.2/license/" + l.detail_info.LicenseID + "/download_pkg"
	l.detail_info.SeatsInfo.SeatList = make(map[string]Seat)
	hwinfo := l.dif.HwInfo
	l.detail_info.SeatsInfo.SeatList[l.Floating_token] = Seat{
		Status:          "active",
		Firmware:        hwinfo.FwBuildVersion,
		LastUpdatedAt:   l.detail_info.CreatedAt,
		Hostname:        hwinfo.DeviceHostname,
		Hwsn:            hwinfo.Hwsn,
		LastRemoteIP:    "1.1.1.1",
		Unsubscribed:    0,
		Model:           hwinfo.Model,
		DeviceID:        l.dif.DeviceID,
		UsedSeats:       1,
		Deactivated:     0,
		LifDownloadPath: l.detail_info.SeatsInfo.LifDownloadPath,
	}

	lif_json, err := json.Marshal(l.lif)
	if err != nil {
		log.Println(err)
		return
	}
	l.Lif = string(lif_json)

	detail_info_json, err := json.Marshal(l.detail_info)
	if err != nil {
		log.Println(err)
		return
	}
	l.Detail_info = string(detail_info_json)

	err = l.encrypt_sign_lif()
	if err != nil {
		log.Println(err)
		return
	}

	_, err = db.NamedExec(`insert or replace into devices (floating_token, detail_info, lif, dif, rawdif, rawlif, license_key, device_id) values 
	(:floating_token, :detail_info, :lif, :dif, :rawdif, :rawlif, :license_key, :device_id)`, l)
	if err != nil {
		log.Println(err)
		return
	}

	return
}

func active_devices() int {
	var count int
	db.Get(&count, "select count(DISTINCT device_id) from floating_tokens")
	return count
}

func (l *device_license) license_active(dif string) (err error) {
	err = l.license_seat_info()
	if err != nil {
		log.Println(err)
		return
	}
	if l.detail_info.SeatsInfo.AvailableSeats == 0 {
		err = errors.New("This license have been activate yet.")
		log.Println(err)
		return
	}
	l.Dif = dif
	err = l.generate_lif()
	if err != nil {
		log.Println(err)
		return
	}


	_, err = db.Exec(`insert or replace into floating_tokens (floating_token, license_key, device_id) 
	values ($1, $2, $3)`, l.Floating_token, l.License_key, l.Device_id)
	if err != nil {
		log.Println(err)
	}
	

	return
}

func (l *device_license) issue_token(dif string) (err error) {
	err = l.license_seat_info()
	if err != nil {
		return
	}
	if l.detail_info.SeatsInfo.AvailableSeats != 0 {
		err = errors.New("This license have not been activate.")
		return
	}
	l.Dif = dif
	err = l.generate_lif()
	return
}

func (l *device_license) license_download() (err error) {
	err = db.Get(&l.Rawlif, "select rawlif from devices where license_key=$1 and device_id=$2",
		l.License_key, l.Device_id)
	if err != nil {
		return
	}
	return
}

func random_string(length int) string {
	rand.Seed(time.Now().UnixNano() + 100)
	b := make([]byte, length)
	rand.Read(b)
	// make sure it not start with 0
	if b[0] <= 0x10 {
		b[0] = (byte)(rand.Intn(255-16) + 16)
	}
	return fmt.Sprintf("%x", b)[:length]
}

var db *sqlx.DB
var dev_limit int

func init() {
	var err error
	log.SetFlags(log.LstdFlags | log.Lshortfile)

	db, err = sqlx.Connect("sqlite3", "license.db")
	if err != nil {
		log.Fatalln(err)
	}
	flag.IntVar(&dev_limit, "n", 100, "")
}
