// structs
package main

import (
	"time"
)

var access_token string = `{
   "access_token":"12345678",
   "token_type":"Bearer",
   "client_version":"c5.0.0_20220119",
   "expires_in":31536000,
   "scope":[
      "license.write",
      "license",
      "package",
      "analytic.write",
      "oscar",
      "device.bind",
      "cloudinstall.write",
      "usher",
      "oscar.trial",
      "oscar.trial.write",
      "package.write",
      "device.model"
   ]
}`

type HwInfo struct {
	Mac            string `json:"mac"`
	Hwsn           string `json:"hwsn"`
	Suid           string `json:"suid"`
	Model          string `json:"model"`
	FwBuildVersion string `json:"fw_build_version"`
	DeviceHostname string `json:"device_hostname"`
}

type Product struct {
	Sku         string   `json:"sku"`
	ProductType string   `json:"product_type"`
	ProductID   string   `json:"product_id"`
	Categories  []string `json:"categories"`
	Name        string   `json:"name"`
}

type LicenseInfo struct {
	Sku             string                 `json:"sku"`
	ValidUntil      string                 `json:"valid_until"`
	AppInternalName string                 `json:"app_internal_name"`
	ValidFrom       string                 `json:"valid_from"`
	ProductType     string                 `json:"product_type"`
	Name            string                 `json:"name"`
	LicenseName     string                 `json:"license_name"`
	Feature         interface{}            `json:"feature"`
	AppliedAt       string                 `json:"applied_at"`
	Categories      []string               `json:"categories"`
	Owner           []string               `json:"owner"`
	Attributes      map[string]interface{} `json:"attributes"`
	AppDisplayName  string                 `json:"app_display_name"`
	Channel         interface{}            `json:"channel"`
	ProductID       string                 `json:"product_id"`
}

type LIF struct {
	LicenseCheckPeriod int         `json:"license_check_period"`
	FloatingToken      string      `json:"floating_token"`
	CreatedAt          time.Time   `json:"created_at"`
	DifID              string      `json:"dif_id"`
	DifSignature       string      `json:"dif_signature"`
	FloatingUUID       string      `json:"floating_uuid"`
	LicenseID          string      `json:"license_id"`
	LicenseInfo        LicenseInfo `json:"license_info"`
	ID                 string      `json:"id"`
	HwInfo             HwInfo      `json:"hw_info"`
}

type DIF struct {
	ID            string    `json:"id"`
	DeviceID      string    `json:"device_id"`
	DeviceType    string    `json:"device_type"`
	Inode         string    `json:"inode"`
	CreatedAt     time.Time `json:"created_at"`
	FloatingUUID  string    `json:"floating_uuid"`
	FloatingToken string    `json:"floating_token"`
	HwInfo        HwInfo    `json:"hw_info"`
}

type Seat struct {
	Deactivated     int64     `json:"deactivated"`
	DeviceID        string    `json:"device_id"`
	Firmware        string    `json:"firmware"`
	Hostname        string    `json:"hostname"`
	Hwsn            string    `json:"hwsn"`
	LastRemoteIP    string    `json:"last_remote_ip"`
	LastUpdatedAt   time.Time `json:"last_updated_at"`
	LifDownloadPath string    `json:"lif_download_path"`
	Model           string    `json:"model"`
	Status          string    `json:"status"`
	Unsubscribed    int64     `json:"unsubscribed"`
	UsedSeats       int64     `json:"used_seats"`
}

type Device_info struct {
	Activation struct {
		AppliedAt    string `json:"applied_at"`
		AssignedDate string `json:"assigned_date"`
		ByUser       string `json:"by_user"`
		Status       string `json:"status"`
	} `json:"activation"`
	DeviceHostname string `json:"device_hostname"`
	DeviceID       string `json:"device_id"`
	FloatingHash   string `json:"floating_hash"`
	FloatingUUID   string `json:"floating_uuid"`
	FwBuildVersion string `json:"fw_build_version"`
	Hwsn           string `json:"hwsn"`
	LicenseFileID  string `json:"license_file_id"`
	Mac            string `json:"mac"`
	Model          string `json:"model"`
	RemoteIP       string `json:"remote_ip"`
	Suid           string `json:"suid"`
}

type DETAIL_INFO struct {
	Available_seats int                    `json:"available_seats"`
	ActivatedAt     time.Time              `json:"activated_at"`
	ActivationIP    string                 `json:"activation_ip"`
	AppDisplayName  string                 `json:"app_display_name"`
	AppInternalName string                 `json:"app_internal_name"`
	AppMinVersion   string                 `json:"app_min_version"`
	Attributes      map[string]interface{} `json:"attributes"`
	CreatedAt       time.Time              `json:"created_at"`
	Device          []Device_info          `json:"device"`
	DeviceType      []string               `json:"device_type"`
	DisplayStatus   string                 `json:"display_status"`
	Duration        struct {
		Day   int64 `json:"day"`
		Month int64 `json:"month"`
		Year  int64 `json:"year"`
	} `json:"duration"`
	ExpiresAt         time.Time `json:"expires_at"`
	GracePeriodStatus string    `json:"grace_period_status"`
	Hashed            bool      `json:"hashed"`
	LicenseCredit     []struct {
		AppliedDate time.Time `json:"applied_date"`
		Duration    struct {
			Day   int64 `json:"day"`
			Month int64 `json:"month"`
			Year  int64 `json:"year"`
		} `json:"duration"`
		LicenseCreditID string `json:"license_credit_id"`
	} `json:"license_credit"`
	LicenseID   string   `json:"license_id"`
	LicenseKey  string   `json:"license_key"`
	LicenseName string   `json:"license_name"`
	Owner       []string `json:"owner"`
	Ownership   struct {
		Email   string `json:"email"`
		IsOwner bool   `json:"is_owner"`
	} `json:"ownership"`
	Product Product `json:"product"`
	Quota   struct {
		MaxDevice int64 `json:"max_device"`
		MaxUser   int64 `json:"max_user"`
	} `json:"quota"`
	RemainDays int64 `json:"remain_days"`
	SeatsInfo  struct {
		AvailableSeats        int64           `json:"available_seats"`
		LifDownloadPath       string          `json:"lif_download_path"`
		MaxSeats              int64           `json:"max_seats"`
		SeatList              map[string]Seat `json:"seat_list"`
		TotalActivated        int64           `json:"total_activated"`
		TotalFreeUnsubscribed int64           `json:"total_free_unsubscribed"`
		TotalSeats            int64           `json:"total_seats"`
		TotalUnsubscribed     int64           `json:"total_unsubscribed"`
	} `json:"seats_info"`
	Status       string    `json:"status"`
	Transferable bool      `json:"transferable"`
	Type         string    `json:"type"`
	UpdatedAt    time.Time `json:"updated_at"`
	User         []string  `json:"user"`
}

type RAW_DIF struct {
	Nonce     string `json:"nonce"`
	AppID     string `json:"app_id"`
	Data      string `json:"data"`
	Signature string `json:"signature"`
}

type RAW_LIF struct {
	Nonce     string `json:"nonce"`
	Data      string `json:"data"`
	Signature string `json:"signature"`
}

type RESP struct {
	Message string      `json:"message"`
	Code    int         `json:"code"`
	Result  interface{} `json:"result"`
}
