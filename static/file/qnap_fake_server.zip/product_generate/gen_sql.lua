local json=require"dkjson"


p = io.open("product.json","r")
p = p:read"*a"

p = json.decode(p)

attributes = {}
products = {}

for _,pro in pairs(p.data) do
	attrs = {}
	for _,attr in pairs(pro.attributes) do
		if attr.value == "true" then
			attrs[attr.code] = true
		elseif attr.value == "false" then
			attrs[attr.code] = false
		elseif attr.code == "child_skus" then
		else
			attrs[attr.code] = attr.value
		end

	end

	if attrs.app_internal_name then
		attrs.app_internal_name = string.match(attrs.app_internal_name, "^\([0-9a-zA-Z-_]*\)")
	end

	sku = pro.sku
	if pro.attributes.child_skus and pro.attributes.child_skus[1] then
		sku = pro.attributes.child_skus[1]
	end

	if sku == "VSKU-LS-CAYINPLAYER-QTSCLD" then
		attrs.transcoding = "1"
	end
	if sku == "VSKU-LS-HM-QTSCLD" then
		attrs.connection = "100"
	end
	if sku == "VSKU-LS-VJBODCLOUD-QTSCLD" then
		attrs.space="100"
	end
	attrs.variant_feature = attrs.variant_feature or "premium"
	attrs.license_name = attrs.app_display_name

	if attrs.app_display_name == "QuTScloud" then
	else

		product = {}
		product.sku = sku
		product.product_type = attrs.product_class
		product.categories = pro.categories
		product.name = attrs.app_display_name
		product.product_id = tostring(pro.id)

		attributes[sku] = attrs
		products[sku] = product
	end

end

os.execute("mkdir files")

license = "L1111-11111-11111-11111-11111"
f = io.open("license.sql", "w")
sql = [[insert or replace into license_keys (license_key, attributes, product) values ("%s", readfile("%s"), readfile("%s"));]]
index = 1
function replace_char(pos, str, r)
    return str:sub(1, pos-1) .. r .. str:sub(pos+1)
end
for k,v in pairs(attributes) do
	index = index+1
	if index % 6 == 0 then
		index = index+1
	end
	lic = replace_char(index, license, "8")
	
	f1 = io.open("files/" .. k .. ".attr.json", "w")
	f2 = io.open("files/" .. k .. ".product.json", "w")
	f1:write(json.encode(v, {indent = "\t"}))
	f2:write(json.encode(products[k], {indent = "\t"}))

	s = string.format(sql, lic , "files/" .. k .. ".attr.json", "files/" .. k .. ".product.json")
	f1:close()
	f2:close()
	f:write(s)
	f:write"\n"
	print(lic, products[k].name)
end
f:close()


