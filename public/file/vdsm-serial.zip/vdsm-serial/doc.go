// vdsm-serial project doc.go

/*
vdsm-serial document
*/
package main
